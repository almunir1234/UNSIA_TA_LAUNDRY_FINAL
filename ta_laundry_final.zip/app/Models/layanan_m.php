<?php

namespace App\Models;

use CodeIgniter\Model;


class Layanan_m extends Model
{

    protected $table = "layanan";
    protected $primaryKey = "id_layanan";
    protected $allowedFields = ['id_layanan', 'nama_paket', 'jenis', 'harga', 'delete_at'];
}
