<?php

namespace App\Models;

use CodeIgniter\Model;


class Pelanggan_m extends Model
{

    protected $table = "pelanggan";
    protected $primaryKey = "id_pelanggan";
    protected $allowedFields = ['id_pelanggan', 'nama_pelanggan', 'alamat', 'no_telp', 'delete_at'];
}
