<?php

namespace App\Models;

use CodeIgniter\Model;


class Users_m extends Model
{

    protected $table = "users";
    protected $primaryKey = "id_users";
    protected $allowedFields = ['id_users', 'nama_lengkap', 'username', 'password', 'role'];

    public function ubahDataAkunProcess($id_users, $data)
    {
        $this->db = db_connect();
        $this->db = \Config\database::connect();
        $this->builder = $this->db->table('users');
        $this->builder->where('id_users', $id_users);
        $this->builder->update($data);
    }
}
