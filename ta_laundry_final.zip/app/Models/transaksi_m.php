<?php

namespace App\Models;

use CodeIgniter\Model;


class Transaksi_m extends Model
{

    protected $table = "transaksi";
    protected $primaryKey = "no_transaksi";
    protected $allowedFields = ['no_transaksi', 'id_pelanggan', 'tgl_terima', 'status', 'tgl_selesai', 'tgl_pembayaran'];

    public function getTransaksiData($keyword = null)
    {
        $builder = $this->select('transaksi.*, pelanggan.nama_pelanggan')
            ->join('pelanggan', 'pelanggan.id_pelanggan = transaksi.id_pelanggan', 'left');

        if (!empty($keyword)) {
            $kw = strtolower(trim($keyword));

            $builder->groupStart();

            // 1. Cari Nama Pelanggan
            $builder->like('pelanggan.nama_pelanggan', $kw);

            // 2. Cari No Transaksi
            $builder->orLike('transaksi.no_transaksi', $kw);

            // 3. Cari Status Pembayaran (lunas / belum lunas)
            // $builder->orLike('transaksi.tgl_pembayaran', $kw);
            if (strpos('belum', $kw) !== false) {
                $builder->orWhere('transaksi.tgl_pembayaran IS NULL');
            }
            if (strpos('lunas', $kw) !== false) {
                $builder->orWhere('transaksi.tgl_pembayaran IS NOT NULL');
            }

            // 4. Status Pengerjaan (Proses jika tgl_selesai NULL, Selesai jika terisi)
            // Ganti logika pencarian status pengerjaan lama dengan ini:
            if (in_array($kw, ['antri', 'proses', 'selesai'])) {
                $builder->orWhere('transaksi.status', $kw);
            }

            // 5. Pencarian Tanggal Berdasarkan tgl_terima
            $monthsMap = [
                'januari' => '01',
                'jan' => '01',
                'februari' => '02',
                'feb' => '02',
                'maret' => '03',
                'mar' => '03',
                'april' => '04',
                'apr' => '04',
                'mei' => '05',
                'juni' => '06',
                'jun' => '06',
                'juli' => '07',
                'jul' => '07',
                'agustus' => '08',
                'agu' => '08',
                'ags' => '08',
                'september' => '09',
                'sep' => '09',
                'oktober' => '10',
                'okt' => '10',
                'november' => '11',
                'nov' => '11',
                'desember' => '12',
                'des' => '12',
            ];

            $numericKw = $kw;
            foreach ($monthsMap as $indo => $num) {
                if (strpos($numericKw, $indo) !== false) {
                    $numericKw = str_replace($indo, $num, $numericKw);
                }
            }

            $builder->orLike('transaksi.tgl_terima', $kw);
            $builder->orLike('DATE_FORMAT(transaksi.tgl_terima, "%d-%b-%Y")', $kw);
            $builder->orLike('DATE_FORMAT(transaksi.tgl_terima, "%d %m %Y")', $numericKw);
            $builder->orLike('DATE_FORMAT(transaksi.tgl_terima, "%d-%m-%Y")', $numericKw);

            $builder->groupEnd();
        }

        return $builder->orderBy('transaksi.no_transaksi', 'DESC');
    }
}
