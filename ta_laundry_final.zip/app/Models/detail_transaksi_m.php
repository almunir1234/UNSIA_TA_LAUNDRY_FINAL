<?php

namespace App\Models;

use CodeIgniter\Model;


class Detail_transaksi_m extends Model
{

    protected $table = "detail_transaksi";
    protected $primaryKey = "id_layanan";
    protected $allowedFields = ['id_detail', 'no_transaksi', 'jumlah', 'harga_satuan', 'total_harga'];

    public function getRekapPendapatan()
    {
        $today     = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $thisMonth = date('m');
        $thisYear  = date('Y');

        // Base query builder: hanya menghitung transaksi yang sudah memiliki tgl_pembayaran
        $baseQuery = function () {
            return $this->db->table('detail_transaksi')
                ->selectSum('detail_transaksi.total_harga', 'total')
                ->join('transaksi', 'transaksi.no_transaksi = detail_transaksi.no_transaksi')
                ->where('transaksi.tgl_pembayaran IS NOT NULL');
        };

        return [
            // 1. Hari Ini (berdasarkan tanggal bayar hari ini)
            'hari_ini' => $baseQuery()
                ->where('DATE(transaksi.tgl_pembayaran)', $today)
                ->get()->getRowArray()['total'] ?? 0,

            // 2. Kemarin
            'kemarin' => $baseQuery()
                ->where('DATE(transaksi.tgl_pembayaran)', $yesterday)
                ->get()->getRowArray()['total'] ?? 0,

            // 3. Minggu Ini (Senin s.d. Minggu)
            'minggu_ini' => $baseQuery()
                ->where('transaksi.tgl_pembayaran >=', date('Y-m-d 00:00:00', strtotime('monday this week')))
                ->where('transaksi.tgl_pembayaran <=', date('Y-m-d 23:59:59', strtotime('sunday this week')))
                ->get()->getRowArray()['total'] ?? 0,

            // 4. Bulan Ini
            'bulan_ini' => $baseQuery()
                ->where('MONTH(transaksi.tgl_pembayaran)', $thisMonth)
                ->where('YEAR(transaksi.tgl_pembayaran)', $thisYear)
                ->get()->getRowArray()['total'] ?? 0,
        ];
    }
}
