<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');



// TA LAUNDRY 2026

// AUTH ROUTES
$routes->group('auth', function ($routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('loginProcess', 'Auth::loginProcess');
    $routes->get('logout', 'Auth::logout');
});

// CHANGE PASS ROUTES
$routes->post('ubahDataAkunProcess', 'Users::ubahDataAkunProcess');

// Navigasi Menu Users
// menu admin
$routes->get('dashboardAdmin', 'MenuUsers::dashboardAdmin', ['filter' => 'authGuard']);
$routes->get('daftarTransaksi', 'MenuUsers::daftarTransaksi', ['filter' => 'authGuard']);
$routes->get('detailTransaksi/(:segment)', 'MenuUsers::detailTransaksi/$1', ['filter' => 'authGuard']);
$routes->get('daftarPelanggan', 'MenuUsers::daftarPelanggan', ['filter' => 'authGuard']);
$routes->get('daftarLayanan', 'MenuUsers::daftarLayanan', ['filter' => 'authGuard']);

// menu owner
$routes->get('dashboardOwner', 'MenuUsers::dashboardOwner', ['filter' => 'authGuard']);
$routes->get('lapPendapatan', 'MenuUsers::lapPendapatan', ['filter' => 'authGuard']);

// Get data di tabel master
$routes->get('getPelangganAjax', 'MenuUsers::getPelangganAjax', ['filter' => 'authGuard']);
$routes->get('getLayananAjax', 'MenuUsers::getLayananAjax', ['filter' => 'authGuard']);
$routes->get('getDetailTransaksiAjax/(:segment)', 'MenuUsers::getDetailTransaksiAjax/$1', ['filter' => 'authGuard']);

// Proses
// Transaksi
$routes->post('simpanTransaksi', 'MenuUsers::simpanTransaksi', ['filter' => 'authGuard']); //Simpan Transaksi
$routes->post('updateTransaksi', 'MenuUsers::updateTransaksi', ['filter' => 'authGuard']); //Edit Transaksi
$routes->get('hapusTransaksi/(:segment)', 'MenuUsers::hapusTransaksi/$1', ['filter' => 'authGuard']); //Hapus Transaksi

// Pelanggan
$routes->post('simpanPelanggan', 'MenuUsers::simpanPelanggan', ['filter' => 'authGuard']); //Simpan Pelanggan
$routes->post('updatePelanggan', 'MenuUsers::updatePelanggan', ['filter' => 'authGuard']); //Edit Pelanggan
$routes->get('hapusPelanggan/(:segment)', 'MenuUsers::hapusPelanggan/$1', ['filter' => 'authGuard']); //Hapus Pelanggan


// Pelanggan
$routes->post('simpanLayanan', 'MenuUsers::simpanLayanan', ['filter' => 'authGuard']); //Simpan Layanan
$routes->post('updateLayanan', 'MenuUsers::updateLayanan', ['filter' => 'authGuard']); //Edit Layanan
$routes->get('hapusLayanan/(:segment)', 'MenuUsers::hapusLayanan/$1', ['filter' => 'authGuard']); //Hapus Layanan




/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
