<?php

namespace App\Controllers;

use App\Models\Admin_m;

class Admin extends BaseController
{

    protected $admin;

    public function __construct()
    {
        $this->admin = new Admin_m();
    }



    public function changePassAdminProcess()
    {
        $data['username'] = $this->request->getPost('UN');
        $data['password'] = $this->request->getPost('PW');

        $id_admin = session()->get('id_admin');
        $this->admin->changePassAdmin($id_admin, $data);

        session()->destroy();

        return redirect()->to(site_url('auth/login'));
    }
}
