<?php

namespace App\Controllers;

use App\Models\Users_m;

class Auth extends BaseController
{
    protected $users;

    function __construct()
    {
        $this->users = new Users_m();
    }

    // Halaman Login
    public function login()
    {
        return view('formLogin');
    }

    // Proses Login
    public function loginProcess()
    {
        $session = session();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $this->users->where('username', $username)->first();


        if ($user && $username == $user['username'] && $password == $user['password']) {
            $sessionData = [
                'id_users'    => $user['id_users'],
                'nama_users'  => $user['nama_lengkap'],
                'username'  => $user['username'],
                'password'  => $user['password'],
                'role'  => $user['role'],
                'logged_in'   => TRUE
            ];
            $session->set($sessionData);
            if ($user['role'] == 'admin') {
                return redirect()->to(site_url('dashboardAdmin'));
            } else {
                return redirect()->to(site_url('dashboardOwner'));
            }
        } else {
            $session->setFlashdata('error', 'Username atau Password salah!');
            return redirect()->to(site_url('auth/login'));
        }
    }

    public function logout()
    {
        // session()->destroy();

        session()->remove(['id_user', 'nama_users', 'username', 'password', 'role', 'logged_in']);
        return redirect()->to(site_url('auth/login'))->with('Success', 'Anda telah berhasil logout.');
    }
}
