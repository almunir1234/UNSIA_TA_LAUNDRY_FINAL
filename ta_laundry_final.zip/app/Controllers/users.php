<?php

namespace App\Controllers;

use App\Models\Users_m;

class Users extends BaseController
{

    protected $users;

    public function __construct()
    {
        $this->users = new Users_m();
    }



    public function ubahDataAkunProcess()
    {
        $data['nama_lengkap'] = $this->request->getPost('nama_lengkap');
        $data['username'] = $this->request->getPost('username');
        $data['password'] = $this->request->getPost('password');

        $id_users = session()->get('id_users');
        $this->users->ubahDataAkunProcess($id_users, $data);

        // session()->destroy();

        session()->remove(['id_user', 'nama_users', 'username', 'password', 'role', 'logged_in']);
        return redirect()->to(site_url('auth/login'))->with('Success', 'data akun milik anda berhasil diubah.');;
    }
}
