<?php

namespace App\Controllers;

use App\Models\Transaksi_m;
use App\Models\Pelanggan_m;
use App\Models\Layanan_m;
use App\Models\Detail_transaksi_m;

class MenuUsers extends BaseController
{

    protected $transaksi;
    protected $pelanggan;
    protected $layanan;
    protected $detail_transaksi;

    function __construct()
    {
        $this->transaksi = new Transaksi_m();
        $this->pelanggan = new Pelanggan_m();
        $this->layanan = new Layanan_m();
        $this->detail_transaksi = new Detail_transaksi_m();
    }

    public function getPelangganAjax()
    {
        $keyword = $this->request->getGet('q');
        $db = \Config\Database::connect();

        $builder = $db->table('pelanggan')
            ->where('delete_at', null);

        if (!empty($keyword)) {
            $builder->like('nama_pelanggan', $keyword);
        }
        $data = $builder->limit(10)->get()->getResultArray();

        return $this->response->setJSON($data);
    }



    public function getLayananAjax()
    {
        $db = \Config\Database::connect();
        $noTransaksi = $this->request->getGet('no_transaksi');

        $builder = $db->table('layanan');

        if (!empty($noTransaksi)) {
            // Ambil ID layanan yang terikat pada transaksi ini
            $detail = $db->table('detail_transaksi')
                ->select('id_layanan')
                ->where('no_transaksi', $noTransaksi)
                ->get()->getResultArray();

            $usedIds = array_column($detail, 'id_layanan');

            $builder->groupStart()
                ->where('delete_at', null);

            if (!empty($usedIds)) {
                $builder->orWhereIn('id_layanan', $usedIds);
            }

            $builder->groupEnd();
        } else {
            $builder->where('delete_at', null);
        }

        $data = $builder->get()->getResultArray();

        return $this->response->setJSON($data);
    }

    // 1. AJAX: Ambil Header & Detail Transaksi untuk Modal Edit
    public function getDetailTransaksiAjax($noTransaksi)
    {
        $db = \Config\Database::connect();

        $transaksi = $db->table('transaksi')
            ->select('transaksi.*, pelanggan.nama_pelanggan')
            ->join('pelanggan', 'pelanggan.id_pelanggan = transaksi.id_pelanggan', 'left')
            ->where('no_transaksi', $noTransaksi)
            ->get()->getRowArray();

        if (!$transaksi) {
            return $this->response->setJSON(['status' => false, 'message' => 'Data tidak ditemukan']);
        }

        $details = $db->table('detail_transaksi')
            ->select('detail_transaksi.*, layanan.*')
            ->join('layanan', 'layanan.id_layanan = detail_transaksi.id_layanan', 'left')
            ->where('no_transaksi', $noTransaksi)
            ->get()->getResultArray();

        return $this->response->setJSON([
            'status'    => true,
            'transaksi' => $transaksi,
            'details'   => $details
        ]);
    }


    // START FUNCTION TRANSAKSI
    // 3. Proses Simpan Transaksi
    public function simpanTransaksi()
    {
        $db = \Config\Database::connect();

        $idPelanggan = $this->request->getPost('id_pelanggan');
        $tglTerima   = $this->request->getPost('tgl_terima');
        $items       = $this->request->getPost('items'); // Array paket & qty

        if (empty($idPelanggan) || empty($items)) {
            return redirect()->back()->with('error', 'Pelanggan dan Paket Layanan wajib diisi!');
        }

        // Generate No. Transaksi (Format: TR-260827001)
        $dateCode = date('ymd', strtotime($tglTerima));
        $prefix   = 'TR-' . $dateCode;

        $lastRow = $db->table('transaksi')
            ->like('no_transaksi', $prefix, 'after')
            ->orderBy('no_transaksi', 'DESC')
            ->get()->getRowArray();

        if ($lastRow) {
            $lastNum = (int) substr($lastRow['no_transaksi'], -3);
            $nextNum = sprintf('%03d', $lastNum + 1);
        } else {
            $nextNum = '001';
        }
        $noTransaksi = $prefix . $nextNum;

        $db->transBegin();


        // NEW
        // Tambahkan pengecekan ini sebelum insert ke database
        $adaProses = $db->table('transaksi')->where('status', 'proses')->countAllResults() > 0;
        $statusAwal = $adaProses ? 'antri' : 'proses';
        $statusBayar   = $this->request->getPost('pembayaran'); // Nilai dari form: 'lunas' / 'belum lunas'
        $tglPembayaran = ($statusBayar === 'lunas') ? date('Y-m-d H:i:s') : null;

        $db->table('transaksi')->insert([
            'no_transaksi'   => $noTransaksi,
            'id_pelanggan'   => $idPelanggan,
            'tgl_terima'     => $tglTerima,
            'status'         => $statusAwal, // Enum: 'antri', 'proses', 'selesai'
            'tgl_selesai'    => null,
            'tgl_pembayaran' => $tglPembayaran
        ]);

        // 2. Insert Detail Transaksi
        // Insert Detail Transaksi
        foreach ($items as $item) {
            $idLayanan = $item['id_layanan'];
            $jumlah    = (int) $item['jumlah'];

            // Ambil baris paket layanan dari DB
            $layanan = $db->table('layanan')
                ->where('id_layanan', $idLayanan)
                ->get()
                ->getRowArray();

            $hargaSatuan = $layanan['harga'];       // Diambil dari kolom 'harga' tabel layanan
            $totalHarga  = $hargaSatuan * $jumlah;  // Hasil perkalian harga_satuan * jumlah

            $db->table('detail_transaksi')->insert([
                'no_transaksi' => $noTransaksi,
                'id_layanan'   => $idLayanan,
                'jumlah'       => $jumlah,
                'harga_satuan' => $hargaSatuan,
                'total_harga'  => $totalHarga
            ]);
        }

        if ($db->transStatus() === false) {
            $db->transRollback();
            return redirect()->back()->with('error', 'Gagal menyimpan transaksi.');
        }

        $db->transCommit();
        return redirect()->to(site_url('daftarTransaksi'))->with('success', 'Data transaksi berhasil ditambahkan!');
    }


    // 2. UPDATE TRANSAKSI (Ganti Pelanggan & Detail Items)
    public function updateTransaksi()
    {
        $db = \Config\Database::connect();

        $noTransaksi      = $this->request->getPost('no_transaksi');
        $idPelanggan      = $this->request->getPost('id_pelanggan');
        $tglTerima        = $this->request->getPost('tgl_terima');
        $statusPengerjaan = strtolower($this->request->getPost('status_pengerjaan')); // 'antri', 'proses', 'selesai'
        $tglSelesai       = ($statusPengerjaan === 'selesai') ? date('Y-m-d H:i:s') : null;
        $items            = $this->request->getPost('items') ?? []; // Paket layanan dari modal edit

        // Validasi input
        if (empty($noTransaksi) || empty($idPelanggan)) {
            return redirect()->back()->with('error', 'No Transaksi dan Pelanggan wajib diisi!');
        }

        if (empty($items)) {
            return redirect()->back()->with('error', 'Minimal harus memilih 1 paket layanan!');
        }

        $tglSelesai = ($statusPengerjaan === 'selesai') ? date('Y-m-d H:i:s') : null;

        try {
            // Gunakan Transaction dengan Try-Catch agar aman dari error DB
            $db->transStart();

            // ----------------------------------------------------
            // 1. UPDATE HEADER TRANSAKSI
            // ----------------------------------------------------
            $statusBayar = $this->request->getPost('pembayaran');

            // Ambil data lama transaksi untuk cek apakah sebelumnya sudah bayar
            $oldTx = $db->table('transaksi')->where('no_transaksi', $noTransaksi)->get()->getRowArray();

            if ($statusBayar === 'lunas') {
                // Jika sebelumnya belum bayar, catat jam sekarang. Jika sudah bayar sebelumnya, pertahankan tanggal lama.
                $tglPembayaran = !empty($oldTx['tgl_pembayaran']) ? $oldTx['tgl_pembayaran'] : date('Y-m-d H:i:s');
            } else {
                $tglPembayaran = null;
            }

            $db->table('transaksi')
                ->where('no_transaksi', $noTransaksi)
                ->update([
                    'id_pelanggan'   => $idPelanggan,
                    'tgl_terima'     => $tglTerima,
                    'tgl_selesai'    => $tglSelesai,
                    'status'         => $statusPengerjaan,
                    'tgl_pembayaran' => $tglPembayaran
                ]);

            // Logika FCFS: Jika status diubah ke 'selesai', majukan antrian paling awal ke 'proses'
            if ($statusPengerjaan === 'selesai') {
                $adaProsesLain = $db->table('transaksi')->where('status', 'proses')->countAllResults() > 0;

                if (!$adaProsesLain) {
                    $antrianTerdepan = $db->table('transaksi')
                        ->where('status', 'antri')
                        ->orderBy('tgl_terima', 'ASC')
                        ->orderBy('no_transaksi', 'ASC')
                        ->limit(1)
                        ->get()->getRowArray();

                    if ($antrianTerdepan) {
                        $db->table('transaksi')
                            ->where('no_transaksi', $antrianTerdepan['no_transaksi'])
                            ->update(['status' => 'proses']);
                    }
                }
            }

            // ----------------------------------------------------
            // 2. AMBIL DATA DETAIL TRANSAKSI LAMA DARI DATABASE
            // ----------------------------------------------------
            $existingDetails = $db->table('detail_transaksi')
                ->where('no_transaksi', $noTransaksi)
                ->get()->getResultArray();

            $existingMap = [];
            foreach ($existingDetails as $row) {
                $existingMap[$row['id_layanan']] = $row;
            }

            // Susun daftar id_layanan baru dari form edit
            $submittedMap = [];
            foreach ($items as $item) {
                if (isset($item['id_layanan']) && isset($item['jumlah'])) {
                    $submittedMap[$item['id_layanan']] = (int) $item['jumlah'];
                }
            }

            // ----------------------------------------------------
            // 3. PROSES A: HAPUS PAKET YANG DIBUANG
            // (Ada di DB lama, tapi tidak ada di kiriman form baru)
            // ----------------------------------------------------
            foreach ($existingMap as $idLayanan => $oldRow) {
                if (!array_key_exists($idLayanan, $submittedMap)) {
                    $db->table('detail_transaksi')
                        ->where('no_transaksi', $noTransaksi)
                        ->where('id_layanan', $idLayanan)
                        ->delete();
                }
            }

            // ----------------------------------------------------
            // 4. PROSES B: TAMBAH PAKET BARU & UPDATE QTY PAKET LAMA
            // ----------------------------------------------------
            foreach ($submittedMap as $idLayanan => $newQty) {
                // Ambil harga paket layanan dari tabel layanan
                $layanan = $db->table('layanan')->where('id_layanan', $idLayanan)->get()->getRowArray();
                $hargaSatuan = $layanan ? ($layanan['harga'] ?? $layanan['harga_satuan'] ?? 0) : 0;
                $totalHarga  = $hargaSatuan * $newQty;

                if (!array_key_exists($idLayanan, $existingMap)) {
                    // PAKET BARU DITAMBAHKAN -> INSERT
                    $db->table('detail_transaksi')->insert([
                        'no_transaksi' => $noTransaksi,
                        'id_layanan'   => $idLayanan,
                        'jumlah'       => $newQty,
                        'harga_satuan' => $hargaSatuan,
                        'total_harga'  => $totalHarga
                    ]);
                } else {
                    // PAKET SUDAH ADA SEBELUMNYA -> CEK APAKAH JUMLAH/QTY BERUBAH -> UPDATE
                    $oldRow = $existingMap[$idLayanan];
                    if ((int)$oldRow['jumlah'] !== $newQty) {
                        $db->table('detail_transaksi')
                            ->where('no_transaksi', $noTransaksi)
                            ->where('id_layanan', $idLayanan)
                            ->update([
                                'jumlah'       => $newQty,
                                'harga_satuan' => $hargaSatuan,
                                'total_harga'  => $totalHarga
                            ]);
                    }
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return redirect()->back()->with('error', 'Gagal memperbarui transaksi.');
            }

            return redirect()->to(site_url('daftarTransaksi'))->with('success', 'Data transaksi berhasil diperbarui!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan database: ' . $e->getMessage());
        }
    }

    public function hapusTransaksi($noTransaksi)
    {
        $db = \Config\Database::connect();

        // Ambil data transaksi sebelum dihapus
        $tx = $db->table('transaksi')->where('no_transaksi', $noTransaksi)->get()->getRowArray();

        $db->transBegin();

        $db->table('detail_transaksi')->where('no_transaksi', $noTransaksi)->delete();
        $db->table('transaksi')->where('no_transaksi', $noTransaksi)->delete();

        // Jika yang dihapus adalah transaksi yang 'proses', majukan antrian tertua
        if ($tx && $tx['status'] === 'proses') {
            $antrianTerdepan = $db->table('transaksi')
                ->where('status', 'antri')
                ->orderBy('tgl_terima', 'ASC')
                ->orderBy('no_transaksi', 'ASC')
                ->limit(1)
                ->get()->getRowArray();

            if ($antrianTerdepan) {
                $db->table('transaksi')
                    ->where('no_transaksi', $antrianTerdepan['no_transaksi'])
                    ->update(['status' => 'proses']);
            }
        }

        if ($db->transStatus() === false) {
            $db->transRollback();
            return redirect()->to(site_url('daftarTransaksi'))->with('error', 'Gagal menghapus transaksi.');
        }

        $db->transCommit();
        return redirect()->to(site_url('daftarTransaksi'))->with('success', 'Data transaksi berhasil dihapus!');
    }

    // END FUNCTION TRANSAKSI

    // Halaman Users
    // Admin
    public function dashboardAdmin()
    {

        // total pelanggan
        // $totalPelanggan = $this->pelanggan->countAll();
        $totalPelanggan = $this->pelanggan
            ->where('delete_at', null)
            ->countAllResults();



        // total transaksi
        $totalTransaksi = $this->transaksi->countAll();
        // Cek total transaksi selesai
        $transaksiSelesai = $this->transaksi->where('status', 'selesai')->countAllResults();
        $transaksiProses  = $this->transaksi->where('status', 'proses')->countAllResults();
        $transaksiAntri   = $this->transaksi->where('status', 'antri')->countAllResults();


        $data = [
            'total_pelanggan' => $totalPelanggan,
            'total_transaksi' => $totalTransaksi,
            'total_transaksi_antri' => $transaksiAntri,
            'total_transaksi_selesai' => $transaksiSelesai,
            'total_transaksi_proses' => $transaksiProses
        ];

        return view('admin/dashboard', $data);
    }
    public function daftarTransaksi()
    {
        $keyword = $this->request->getGet('keyword');
        $currentPage = $this->request->getVar('page_transaksi') ? $this->request->getVar('page_transaksi') : 1;
        $perPage = 5; // Jumlah data per halaman

        $transaksiData = $this->transaksi->getTransaksiData($keyword);

        $data = [
            'transaksi'   => $transaksiData->paginate($perPage, 'transaksi'),
            'pager'       => $this->transaksi->pager,
            'keyword'     => $keyword,
            'currentPage' => $currentPage,
            'perPage'     => $perPage
        ];

        return view('admin/daftar_transaksi', $data);
    }

    public function detailTransaksi($noTransaksi)
    {
        $db = \Config\Database::connect();

        // Data Transaksi & Pelanggan
        $transaksi = $db->table('transaksi t')
            ->join('pelanggan p', 'p.id_pelanggan = t.id_pelanggan')
            ->where('t.no_transaksi', $noTransaksi)
            ->get()->getRowArray();

        if (!$transaksi) {
            return redirect()->to(site_url('daftarTransaksi'))->with('error', 'Transaksi tidak ditemukan.');
        }

        // Data Detail Barang / Layanan
        $detail = $db->table('detail_transaksi dt')
            ->join('layanan l', 'l.id_layanan = dt.id_layanan')
            ->where('dt.no_transaksi', $noTransaksi)
            ->get()->getResultArray();

        $data = [
            'transaksi' => $transaksi,
            'detail'    => $detail
        ];

        return view('admin/detail_transaksi', $data);
    }

    // ==========================================
    // DAFTAR PELANGGAN (CRUD & SEARCH)
    // ==========================================
    public function daftarPelanggan()
    {
        $keyword = $this->request->getGet('keyword');
        $page    = (int) ($this->request->getGet('page') ?? 1);
        $perPage = 5;

        $db = \Config\Database::connect();
        $builder = $db->table('pelanggan');

        $deletedCol = $db->fieldExists('delete_at', 'pelanggan') ? 'delete_at' : 'deleted_at';
        $builder->where("{$deletedCol} IS NULL");

        if (!empty($keyword)) {
            $builder->groupStart()
                ->like('nama_pelanggan', $keyword)
                ->orLike('no_telp', $keyword)
                ->orLike('alamat', $keyword)
                ->groupEnd();
        }

        $totalRows = $builder->countAllResults(false);
        $offset    = ($page - 1) * $perPage;

        $pelanggan = $builder->orderBy('id_pelanggan', 'DESC')
            ->limit($perPage, $offset)
            ->get()->getResultArray();

        $pager = \Config\Services::pager();
        $pagerLinks = $pager->makeLinks($page, $perPage, $totalRows, 'custom_pager');

        $data = [
            'keyword'     => $keyword,
            'pelanggan'   => $pelanggan,
            'pager'       => $pagerLinks,
            'currentPage' => $page,
            'perPage'     => $perPage
        ];

        return view('admin/daftar_pelanggan', $data);
    }

    public function simpanPelanggan()
    {
        $db = \Config\Database::connect();
        $db->table('pelanggan')->insert([
            'nama_pelanggan' => $this->request->getPost('nama_pelanggan'),
            'no_telp'          => $this->request->getPost('no_hp'),
            'alamat'          => $this->request->getPost('alamat')
        ]);
        return redirect()->to(site_url('daftarPelanggan'))->with('success', 'Data pelanggan berhasil ditambahkan.');
    }

    public function updatePelanggan()
    {
        $db = \Config\Database::connect();
        $id = $this->request->getPost('id_pelanggan');
        $db->table('pelanggan')->where('id_pelanggan', $id)->update([
            'nama_pelanggan' => $this->request->getPost('nama_pelanggan'),
            'no_telp'          => $this->request->getPost('no_hp'),
            'alamat'          => $this->request->getPost('alamat')
        ]);
        return redirect()->to(site_url('daftarPelanggan'))->with('success', 'Data pelanggan berhasil diperbarui.');
    }

    public function hapusPelanggan($id)
    {
        $db = \Config\Database::connect();

        // Cek apakah pelanggan sudah pernah bertransaksi
        $hasTransaction = $db->table('transaksi')
            ->where('id_pelanggan', $id)
            ->countAllResults() > 0;

        if ($hasTransaction) {
            // Soft Delete: Hanya isi timestamp hapus jika data sudah terikat transaksi
            $deletedCol = $db->fieldExists('delete_at', 'pelanggan') ? 'delete_at' : 'deleted_at';
            $db->table('pelanggan')->where('id_pelanggan', $id)->update([
                $deletedCol => date('Y-m-d H:i:s')
            ]);
            $pesan = 'Data pelanggan berhasil dihapus.'; //dinonaktifkan
        } else {
            // Hard Delete: Hapus permanen dari database jika belum pernah bertransaksi
            $db->table('pelanggan')->where('id_pelanggan', $id)->delete();
            $pesan = 'Data pelanggan berhasil dihapus.'; //hapus permanen
        }

        return redirect()->to(site_url('daftarPelanggan'))->with('success', $pesan);
    }


    // ==========================================
    // DAFTAR LAYANAN (CRUD & SEARCH)
    // ==========================================
    public function daftarLayanan()
    {
        $keyword = $this->request->getGet('keyword');
        $page    = (int) ($this->request->getGet('page') ?? 1);
        $perPage = 5;

        $db = \Config\Database::connect();
        $builder = $db->table('layanan');

        $deletedCol = $db->fieldExists('delete_at', 'layanan') ? 'delete_at' : 'deleted_at';
        $builder->where("{$deletedCol} IS NULL");

        if (!empty($keyword)) {
            $builder->groupStart()
                ->like('nama_paket', $keyword)
                ->orLike('jenis', $keyword)
                ->groupEnd();
        }

        $totalRows = $builder->countAllResults(false);
        $offset    = ($page - 1) * $perPage;

        $layanan = $builder->orderBy('id_layanan', 'DESC')
            ->limit($perPage, $offset)
            ->get()->getResultArray();

        $pager = \Config\Services::pager();
        $pagerLinks = $pager->makeLinks($page, $perPage, $totalRows, 'custom_pager');

        $data = [
            'keyword'     => $keyword,
            'layanan'     => $layanan,
            'pager'       => $pagerLinks,
            'currentPage' => $page,
            'perPage'     => $perPage
        ];

        return view('admin/daftar_layanan', $data);
    }

    public function simpanLayanan()
    {
        $db = \Config\Database::connect();
        $db->table('layanan')->insert([
            'nama_paket' => $this->request->getPost('nama_paket'),
            'jenis'      => $this->request->getPost('jenis'),
            'harga'      => $this->request->getPost('harga')
        ]);
        return redirect()->to(site_url('daftarLayanan'))->with('success', 'Data layanan berhasil ditambahkan.');
    }

    public function updateLayanan()
    {
        $db = \Config\Database::connect();
        $id = $this->request->getPost('id_layanan');
        $db->table('layanan')->where('id_layanan', $id)->update([
            'nama_paket' => $this->request->getPost('nama_paket'),
            'jenis'      => $this->request->getPost('jenis'),
            'harga'      => $this->request->getPost('harga')
        ]);
        return redirect()->to(site_url('daftarLayanan'))->with('success', 'Data layanan berhasil diperbarui.');
    }

    public function hapusLayanan($id)
    {
        $db = \Config\Database::connect();

        // Cek apakah layanan sudah pernah digunakan di detail_transaksi
        $hasTransaction = $db->table('detail_transaksi')
            ->where('id_layanan', $id)
            ->countAllResults() > 0;

        if ($hasTransaction) {
            // Soft Delete: Hanya isi timestamp hapus jika layanan pernah digunakan
            $deletedCol = $db->fieldExists('delete_at', 'layanan') ? 'delete_at' : 'deleted_at';
            $db->table('layanan')->where('id_layanan', $id)->update([
                $deletedCol => date('Y-m-d H:i:s')
            ]);
            $pesan = 'Data layanan berhasil dihapus.'; //dinonaktifkan
        } else {
            // Hard Delete: Hapus permanen jika layanan belum pernah dipakai sama sekali
            $db->table('layanan')->where('id_layanan', $id)->delete();
            $pesan = 'Data layanan berhasil dihapus.'; //hapus permanen
        }

        return redirect()->to(site_url('daftarLayanan'))->with('success', $pesan);
    }


    // OWner
    public function dashboardOwner()
    {

        // Memanggil method dari model
        $rekap = $this->detail_transaksi->getRekapPendapatan();

        $data = [
            'pendapatan_hari_ini'   => $rekap['hari_ini'],
            'pendapatan_kemarin'    => $rekap['kemarin'],
            'pendapatan_minggu_ini' => $rekap['minggu_ini'],
            'pendapatan_bulan_ini'  => $rekap['bulan_ini'],
        ];

        return view('owner/dashboard', $data);
    }


    public function lapPendapatan()
    {
        $tglMulai = $this->request->getGet('tgl_mulai');
        $tglAkhir = $this->request->getGet('tgl_akhir');
        $page     = (int) ($this->request->getGet('page') ?? 1);
        $perPage  = 5; // Jumlah data harian per halaman

        $reports         = [];
        $totalPendapatan = 0;
        $pagerLinks      = '';

        if (!empty($tglMulai) && !empty($tglAkhir)) {
            $db = \Config\Database::connect();

            // 1. Hitung Total Pendapatan Keseluruhan (Grand Total) dalam Rentang Filter
            $totalQuery = $db->table('transaksi t')
                ->select("SUM(dt.total_harga) as total_grand")
                ->join('detail_transaksi dt', 'dt.no_transaksi = t.no_transaksi')
                ->where('t.tgl_pembayaran IS NOT NULL')
                ->where('DATE(t.tgl_pembayaran) >=', $tglMulai)
                ->where('DATE(t.tgl_pembayaran) <=', $tglAkhir)
                ->get()->getRowArray();

            $totalPendapatan = (float) ($totalQuery['total_grand'] ?? 0);

            // 2. Hitung Total Baris Data Harian (untuk jumlah page)
            $countQuery = $db->table('transaksi t')
                ->select("DATE(t.tgl_pembayaran)")
                ->where('t.tgl_pembayaran IS NOT NULL')
                ->where('DATE(t.tgl_pembayaran) >=', $tglMulai)
                ->where('DATE(t.tgl_pembayaran) <=', $tglAkhir)
                ->groupBy('DATE(t.tgl_pembayaran)')
                ->get()->getResultArray();

            $totalRows = count($countQuery);

            // 3. Ambil Data Harian Sesuai Limit & Offset Pagination
            $offset = ($page - 1) * $perPage;
            $reports = $db->table('transaksi t')
                ->select("DATE(t.tgl_pembayaran) as tanggal, SUM(dt.total_harga) as total_harian")
                ->join('detail_transaksi dt', 'dt.no_transaksi = t.no_transaksi')
                ->where('t.tgl_pembayaran IS NOT NULL')
                ->where('DATE(t.tgl_pembayaran) >=', $tglMulai)
                ->where('DATE(t.tgl_pembayaran) <=', $tglAkhir)
                ->groupBy('DATE(t.tgl_pembayaran)')
                ->orderBy('DATE(t.tgl_pembayaran)', 'ASC')
                ->limit($perPage, $offset)
                ->get()->getResultArray();

            // 4. Generate Link Pagination
            $pager = \Config\Services::pager();
            $pagerLinks = $pager->makeLinks($page, $perPage, $totalRows, 'custom_pager');
        }

        $data = [
            'tglMulai'        => $tglMulai,
            'tglAkhir'        => $tglAkhir,
            'reports'         => $reports,
            'totalPendapatan' => $totalPendapatan,
            'pager'           => $pagerLinks,
            'currentPage'     => $page,
            'perPage'         => $perPage
        ];

        return view('owner/lap_pendapatan', $data);
    }
}
