<?php $pager->setSurroundCount(2) ?>

<nav aria-label="Page navigation" class="mt-4">
    <ul class="pagination justify-content-end mb-0">
        <!-- Tombol Prev -->
        <?php if ($pager->hasPrevious()) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $pager->getPrevious() ?>" aria-label="Previous">Prev</a>
            </li>
        <?php else : ?>
            <li class="page-item disabled">
                <span class="page-link" aria-disabled="true">Prev</span>
            </li>
        <?php endif ?>

        <!-- Nomor Halaman -->
        <?php foreach ($pager->links() as $link) : ?>
            <li class="page-item <?= $link['active'] ? 'active' : '' ?>">
                <a class="page-link" href="<?= $link['uri'] ?>">
                    <?= $link['title'] ?>
                </a>
            </li>
        <?php endforeach ?>

        <!-- Tombol Next -->
        <?php if ($pager->hasNext()) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $pager->getNext() ?>" aria-label="Next">Next</a>
            </li>
        <?php else : ?>
            <li class="page-item disabled">
                <span class="page-link" aria-disabled="true">Next</span>
            </li>
        <?php endif ?>
    </ul>
</nav>