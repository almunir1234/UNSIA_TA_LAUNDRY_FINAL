<?= $this->extend('Views/template.php'); ?>

<?= $this->section('tittle'); ?>
<title>Admin - Detail Transaksi</title>
<?= $this->endSection(); ?>

<?= $this->section('css_content'); ?>
<style>
    /* ==========================================
       1. TAMPILAN UNTUK LAYAR MONITOR (SCREEN)
       ========================================== */
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark, #000);
    }

    .info-card {
        border: 1px solid var(--text-dark, #000);
        border-radius: 6px;
        padding: 1.25rem;
        background-color: #fff;
        margin-bottom: 1.5rem;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 1.5rem;
    }

    .info-item {
        display: flex;
        margin-bottom: 0.5rem;
        font-size: 0.95rem;
    }

    .info-item .label {
        font-weight: 700;
        width: 140px;
        flex-shrink: 0;
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid var(--text-dark, #000);
        padding: 0.75rem;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table th {
        font-weight: 600;
        background-color: #f8f9fa;
    }

    .btn-custom {
        border: 1px solid var(--text-dark, #000);
        background-color: white;
        font-weight: 600;
        padding: 0.5rem 1.5rem;
        border-radius: 4px;
        transition: 0.2s;
        text-decoration: none;
        color: var(--text-dark, #000);
        display: inline-block;
    }

    .btn-custom:hover {
        background-color: var(--bg-light, #f3f4f6);
    }

    /* Area Thermal disembunyikan pada layar monitor */
    #area-cetak {
        display: none;
    }

    /* ==========================================
       2. TAMPILAN KHUSUS PRINTER THERMAL (PRINT)
       ========================================== */
    @media print {
        @page {
            size: 58mm auto;
            margin: 0;
        }

        body * {
            visibility: hidden;
        }

        .screen-view {
            display: none !important;
        }

        #area-cetak,
        #area-cetak * {
            visibility: visible;
        }

        #area-cetak {
            display: block !important;
            position: absolute;
            left: 0;
            top: 0;
            width: 58mm;
            padding: 1mm 2mm;
            font-family: 'Courier New', Courier, monospace;
            font-size: 8.5pt;
            line-height: 1.15;
            color: #000;
            background: #fff;
            page-break-inside: avoid;
            break-inside: avoid;
        }


    }
</style>
<?= $this->endSection(); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Admin</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<!-- ==========================================
     TAMPILAN MONITOR (BESAR & KONSISTEN)
     ========================================== -->
<main class="page-content screen-view">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="page-title mb-0">Detail Transaksi</h1>
        <div>
            <a href="<?= site_url('daftarTransaksi'); ?>" class="btn-custom me-2">
                <i class="fa-solid fa-arrow-left"></i> Kembali
            </a>
            <button onclick="window.print()" class="btn btn-primary fw-bold" style="padding: 0.5rem 1.5rem;">
                <i class="fa-solid fa-print"></i> Cetak Nota
            </button>
        </div>
    </div>

    <!-- Informational Card -->
    <div class="info-card">
        <div class="info-grid">
            <div>
                <h5 class="fw-bold mb-3 border-bottom pb-2">Informasi Transaksi</h5>
                <div class="info-item">
                    <span class="label">No. Transaksi</span>
                    <span>: <strong><?= esc($transaksi['no_transaksi']); ?></strong></span>
                </div>
                <div class="info-item">
                    <span class="label">Tgl. Order</span>
                    <span>: <?= date('d-M-Y', strtotime($transaksi['tgl_terima'])); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Tgl. Selesai</span>
                    <span>: <?= !empty($transaksi['tgl_selesai']) ? date('d-M-Y', strtotime($transaksi['tgl_selesai'])) : '-'; ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Status Pesanan</span>
                    <span>:
                        <?php if (esc($transaksi['status']) == 'antri'): ?>
                            <span class="badge bg-secondary"><?= esc($transaksi['status']); ?></span>
                        <?php elseif (esc($transaksi['status']) == 'proses'): ?>
                            <span class="badge bg-warning"><?= esc($transaksi['status']); ?></span>
                        <?php else: ?>
                            <span class="badge bg-success"><?= esc($transaksi['status']); ?></span>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="info-item">
                    <span class="label">Status Pembayaran</span>
                    <span>:
                        <?php if (!empty($transaksi['tgl_pembayaran'])): ?>
                            <span class="badge bg-success">Lunas</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Belum Lunas</span>
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <div>
                <h5 class="fw-bold mb-3 border-bottom pb-2">Informasi Pelanggan</h5>
                <div class="info-item">
                    <span class="label">Nama Pelanggan</span>
                    <span>: <?= esc($transaksi['nama_pelanggan']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">No. HP / WA</span>
                    <span>: <?= esc($transaksi['no_telp']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Alamat</span>
                    <span>: <?= esc($transaksi['alamat']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Petugas / Kasir</span>
                    <span>: <?= session()->get('nama_users'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabel Layanan / Items -->
    <div class="table-responsive">
        <table class="custom-table">
            <thead>
                <tr>
                    <th style="width: 8%">No</th>
                    <th>Nama Paket Layanan</th>
                    <th style="width: 15%">Jumlah</th>
                    <th style="width: 20%">Harga Satuan</th>
                    <th style="width: 20%">Total Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $total_biaya = 0;
                foreach ($detail as $item):
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td class="text-start ps-3"><?= esc($item['nama_paket']); ?></td>
                        <td><?= esc($item['jumlah']); ?></td>
                        <td class="text-end pe-3">Rp <?= number_format($item['harga_satuan'], 0, ',', '.'); ?></td>
                        <td class="text-end pe-3">Rp <?= number_format($item['total_harga'], 0, ',', '.'); ?></td>
                    </tr>
                <?php
                    $total_biaya += $item['total_harga'];
                endforeach;
                ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #f8f9fa;">
                    <td colspan="4" class="text-end fw-bold fs-5 pe-3">JUMLAH TOTAL</td>
                    <td class="text-end fw-bold fs-5 pe-3">Rp <?= number_format($total_biaya, 0, ',', '.'); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</main>

<!-- ==========================================
     FORMAT STRUK TEKS KHUSUS PRINTER THERMAL (58MM)
     ========================================== -->
<div id="area-cetak">
    <div>--------NOTA LAUNDRY--------</div>
    <br>
    <div>----------------------------</div>
    <div>NO : <?= esc($transaksi['no_transaksi']); ?></div>
    <div>TGL. ORDER : <?= date('d/m/Y', strtotime($transaksi['tgl_terima'])); ?></div>
    <div>TGL. SELESAI : <?= !empty($transaksi['tgl_selesai']) ? date('d/m/Y', strtotime($transaksi['tgl_selesai'])) : '-'; ?></div>
    <div>STATUS : <?= esc($transaksi['status']); ?></div>
    <div>PEMBAYARAN : <?= !empty($transaksi['tgl_pembayaran']) ? 'lunas' : 'belum lunas'; ?></div>
    <div>KASIR: <?= session()->get('nama_users'); ?></div>
    <div>----------------------------</div>

    <div>NAMA : <?= esc($transaksi['nama_pelanggan']); ?></div>
    <div>HP/WA : <?= esc($transaksi['no_telp']); ?></div>
    <div>ALAMAT : <?= esc($transaksi['alamat']); ?></div>
    <div>----------------------------</div>

    <?php
    $total_biaya_thermal = 0;
    foreach ($detail as $item):
    ?>
        <div><?= esc($item['nama_paket']); ?></div>
        <div>
            <span><?= esc($item['jumlah']); ?> x <?= number_format($item['harga_satuan'], 0, ',', '.'); ?></span>
            <span><?= ' (' . number_format($item['total_harga'], 0, ',', '.') . ')'; ?></span>
        </div>
    <?php
        $total_biaya_thermal += $item['total_harga'];
    endforeach;
    ?>

    <div>----------------------------</div>

    <div>
        <span>TOTAL : </span>
        <span>Rp <?= number_format($total_biaya_thermal, 0, ',', '.'); ?></span>
    </div>

    <div>----------------------------</div>
    <div>-</div>

</div>
<?= $this->endSection(); ?>