<?= $this->extend('Views/template.php'); ?>
<?= $this->section('tittle'); ?>
<title>Admin - Daftar Layanan</title>
<?= $this->endSection('tittle'); ?>

<?= $this->section('css_content'); ?>
<style>
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark);
    }

    .action-bar {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .search-input {
        border: 1px solid var(--text-dark);
        border-radius: 4px;
        padding: 0.5rem;
        outline: none;
    }

    .btn-custom {
        border: 1px solid var(--text-dark);
        background-color: white;
        font-weight: 600;
        padding: 0.5rem 1.5rem;
        border-radius: 4px;
        transition: 0.2s;
        text-decoration: none;
        color: var(--text-dark);
        display: inline-block;
    }

    .btn-custom:hover {
        background-color: var(--bg-light);
        color: var(--text-dark);
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid var(--text-dark);
        padding: 0.75rem;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table th {
        font-weight: 600;
    }

    .action-btns {
        display: flex;
        gap: 5px;
        justify-content: center;
        flex-wrap: wrap;
    }

    .pagination .page-item:not(:first-child) .page-link {
        margin-left: 5px;
    }

    .page-link {
        color: var(--text-dark);
        border: 1px solid var(--text-dark);
        border-radius: 4px !important;
        font-weight: 600;
    }

    .page-link:hover {
        background-color: var(--light-orange);
        color: var(--primary-orange);
        border-color: var(--primary-orange);
    }

    .page-item.active .page-link {
        background-color: var(--primary-orange);
        color: white;
        border-color: var(--primary-orange);
    }

    .page-item.disabled .page-link {
        color: var(--text-muted);
        border-color: #e5e7eb;
        background-color: #f9fafb;
    }
</style>
<?= $this->endSection('css_content'); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Admin</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<main class="page-content">
    <!-- Cek dan tampilkan pesan 'success' -->
    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('success'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Cek dan tampilkan pesan 'error' -->
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('error'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <h1 class="page-title">Daftar Layanan</h1>

    <div class="row g-4 mt-2">
        <div class="action-bar">
            <!-- Form Pencarian -->
            <form action="<?= site_url('daftarLayanan') ?>" method="get" class="d-flex gap-2">
                <input type="text" name="keyword" value="<?= esc($keyword) ?>" class="search-input" placeholder="Cari paket layanan...">
                <button type="submit" class="btn btn-warning">Cari</button>
                <?php if (!empty($keyword)): ?>
                    <a href="<?= site_url('daftarLayanan') ?>" class="btn-custom" style="background-color: #fee2e2;">Reset</a>
                <?php endif; ?>
            </form>
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambahLayanan">
                <i class="fa-solid fa-plus"></i> Tambah Layanan
            </button>
        </div>

        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th style="width: 8%">No</th>
                        <th>Nama Paket</th>
                        <th>Jenis</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($layanan) && count($layanan) > 0) : ?>
                        <?php
                        $no = 1 + ($perPage * ($currentPage - 1));
                        foreach ($layanan as $row) :
                            $namaPaket = $row['nama_paket'] ?? $row['nama paket'] ?? '-';
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= esc($namaPaket); ?></td>
                                <td><?= esc($row['jenis'] ?? '-'); ?></td>
                                <td>Rp <?= number_format((float) ($row['harga'] ?? 0), 0, ',', '.'); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <button type="button"
                                            class="btn btn-sm btn-info text-white"
                                            data-bs-toggle="modal"
                                            data-bs-target="#modalEditLayanan"
                                            data-id="<?= esc($row['id_layanan']); ?>"
                                            data-nama="<?= esc($namaPaket); ?>"
                                            data-jenis="<?= esc($row['jenis'] ?? ''); ?>"
                                            data-harga="<?= esc($row['harga'] ?? 0); ?>"
                                            style="font-size: 0.8rem;">
                                            Edit
                                        </button>
                                        <a href="<?= site_url('hapusLayanan/' . $row['id_layanan']); ?>"
                                            class="btn-custom py-1 px-2 text-decoration-none text-center"
                                            style="font-size: 0.8rem; background-color: #dc3545; color: white;"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus layanan <?= esc($namaPaket); ?>?')">
                                            Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-center">Data layanan tidak ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Render Pagination -->
        <?php if (!empty($pager)): ?>
            <div class="d-flex justify-content-end mt-4">
                <?= $pager; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- MODAL TAMBAH LAYANAN -->
<div class="modal fade" id="modalTambahLayanan" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Tambah Paket Layanan Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('simpanLayanan'); ?>" method="post">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Nama Paket Layanan</label>
                        <input type="text" name="nama_paket" class="form-control" required placeholder="Contoh: Cuci Komplit">
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Jenis</label>
                        <select name="jenis" class="form-select" required>
                            <option value="" disabled selected>-- Pilih Jenis Layanan --</option>
                            <option value="Kiloan">Kiloan</option>
                            <option value="Satuan">Satuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control" required placeholder="Masukkan nominal harga">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDIT LAYANAN -->
<div class="modal fade" id="modalEditLayanan" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Edit Paket Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('updateLayanan'); ?>" method="post">
                <?= csrf_field(); ?>
                <input type="hidden" name="id_layanan" id="editIdLayanan">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Nama Paket Layanan</label>
                        <input type="text" name="nama_paket" id="editNamaPaket" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Jenis</label>
                        <select name="jenis" id="editJenis" class="form-select" required>
                            <option value="" disabled>-- Pilih Jenis Layanan --</option>
                            <option value="Kiloan">Kiloan</option>
                            <option value="Satuan">Satuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Harga (Rp)</label>
                        <input type="number" name="harga" id="editHarga" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const modalEdit = document.getElementById('modalEditLayanan');
        if (modalEdit) {
            modalEdit.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;

                document.getElementById('editIdLayanan').value = button.getAttribute('data-id') || '';
                document.getElementById('editNamaPaket').value = button.getAttribute('data-nama') || '';
                document.getElementById('editHarga').value = button.getAttribute('data-harga') || 0;

                const jenisVal = (button.getAttribute('data-jenis') || '').trim();
                const selectJenis = document.getElementById('editJenis');

                selectJenis.value = jenisVal;

                if (selectJenis.selectedIndex <= 0) {
                    Array.from(selectJenis.options).forEach(option => {
                        if (option.value.toLowerCase() === jenisVal.toLowerCase()) {
                            selectJenis.value = option.value;
                        }
                    });
                }
            });
        }
    });
</script>
<?= $this->endSection('content'); ?>