<?= $this->extend('Views/template.php'); ?>
<?= $this->section('tittle'); ?>
<title>Admin - Daftar Pelanggan</title>
<?= $this->endSection('tittle'); ?>

<?= $this->section('css_content'); ?>
<style>
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark);
    }

    .action-bar {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .search-input {
        border: 1px solid var(--text-dark);
        border-radius: 4px;
        padding: 0.5rem;
        outline: none;
    }

    .btn-custom {
        border: 1px solid var(--text-dark);
        background-color: white;
        font-weight: 600;
        padding: 0.5rem 1.5rem;
        border-radius: 4px;
        transition: 0.2s;
        text-decoration: none;
        color: var(--text-dark);
        display: inline-block;
    }

    .btn-custom:hover {
        background-color: var(--bg-light);
        color: var(--text-dark);
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid var(--text-dark);
        padding: 0.75rem;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table th {
        font-weight: 600;
    }

    .action-btns {
        display: flex;
        gap: 5px;
        justify-content: center;
        flex-wrap: wrap;
    }

    .pagination .page-item:not(:first-child) .page-link {
        margin-left: 5px;
    }

    .page-link {
        color: var(--text-dark);
        border: 1px solid var(--text-dark);
        border-radius: 4px !important;
        font-weight: 600;
    }

    .page-link:hover {
        background-color: var(--light-orange);
        color: var(--primary-orange);
        border-color: var(--primary-orange);
    }

    .page-item.active .page-link {
        background-color: var(--primary-orange);
        color: white;
        border-color: var(--primary-orange);
    }

    .page-item.disabled .page-link {
        color: var(--text-muted);
        border-color: #e5e7eb;
        background-color: #f9fafb;
    }
</style>
<?= $this->endSection('css_content'); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Admin</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<main class="page-content">
    <!-- Cek dan tampilkan pesan 'success' -->
    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('success'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Cek dan tampilkan pesan 'error' -->
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('error'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <h1 class="page-title">Daftar Pelanggan</h1>

    <div class="row g-4 mt-2">
        <div class="action-bar">
            <!-- Form Pencarian -->
            <form action="<?= site_url('daftarPelanggan') ?>" method="get" class="d-flex gap-2">
                <input type="text" name="keyword" value="<?= esc($keyword) ?>" class="search-input" placeholder="Cari pelanggan...">
                <button type="submit" class="btn btn-warning">Cari</button>
                <?php if (!empty($keyword)): ?>
                    <a href="<?= site_url('daftarPelanggan') ?>" class="btn-custom" style="background-color: #fee2e2;">Reset</a>
                <?php endif; ?>
            </form>
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambahPelanggan">
                <i class="fa-solid fa-plus"></i> Tambah Pelanggan
            </button>
        </div>

        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th style="width: 8%">No</th>
                        <th>Nama Pelanggan</th>
                        <th>No. HP</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($pelanggan) && count($pelanggan) > 0) : ?>
                        <?php
                        $no = 1 + ($perPage * ($currentPage - 1));
                        foreach ($pelanggan as $row) :
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= esc($row['nama_pelanggan']); ?></td>
                                <td><?= esc($row['no_telp'] ?? '-'); ?></td>
                                <td><?= esc($row['alamat'] ?? '-'); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <button type="button"
                                            class="btn btn-sm btn-info text-white"
                                            data-bs-toggle="modal"
                                            data-bs-target="#modalEditPelanggan"
                                            data-id="<?= esc($row['id_pelanggan']); ?>"
                                            data-nama="<?= esc($row['nama_pelanggan']); ?>"
                                            data-hp="<?= esc($row['no_telp']); ?>"
                                            data-alamat="<?= esc($row['alamat']); ?>"
                                            style="font-size: 0.8rem;">
                                            Edit
                                        </button>
                                        <a href="<?= site_url('hapusPelanggan/' . $row['id_pelanggan']); ?>"
                                            class="btn-custom py-1 px-2 text-decoration-none text-center"
                                            style="font-size: 0.8rem; background-color: #dc3545; color: white;"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan <?= esc($row['nama_pelanggan']); ?>?')">
                                            Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-center">Data pelanggan tidak ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Render Pagination -->
        <?php if (!empty($pager)): ?>
            <div class="d-flex justify-content-end mt-4">
                <?= $pager; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- MODAL TAMBAH PELANGGAN -->
<div class="modal fade" id="modalTambahPelanggan" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Tambah Pelanggan Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('simpanPelanggan'); ?>" method="post">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Nama Pelanggan</label>
                        <input type="text" name="nama_pelanggan" class="form-control" required placeholder="Masukkan nama pelanggan">
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">No. HP</label>
                        <input type="text" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx">
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="3" placeholder="Masukkan alamat"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDIT PELANGGAN -->
<div class="modal fade" id="modalEditPelanggan" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Edit Pelanggan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('updatePelanggan'); ?>" method="post">
                <?= csrf_field(); ?>
                <input type="hidden" name="id_pelanggan" id="editIdPelanggan">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Nama Pelanggan</label>
                        <input type="text" name="nama_pelanggan" id="editNamaPelanggan" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">No. HP</label>
                        <input type="text" name="no_hp" id="editNoHp" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label font-weight-bold">Alamat</label>
                        <textarea name="alamat" id="editAlamat" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const modalEdit = document.getElementById('modalEditPelanggan');
        if (modalEdit) {
            modalEdit.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('editIdPelanggan').value = button.getAttribute('data-id') || '';
                document.getElementById('editNamaPelanggan').value = button.getAttribute('data-nama') || '';
                document.getElementById('editNoHp').value = button.getAttribute('data-hp') || '';
                document.getElementById('editAlamat').value = button.getAttribute('data-alamat') || '';
            });
        }
    });
</script>
<?= $this->endSection('content'); ?>