<?= $this->extend('Views/template.php'); ?>
<?= $this->section('tittle'); ?>
<title>Admin - Daftar Transaksi</title>
<?= $this->endSection('tittle'); ?>

<?= $this->section('css_content'); ?>
<style>
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark);
    }

    .action-bar {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .search-input {
        border: 1px solid var(--text-dark);
        border-radius: 4px;
        padding: 0.5rem;
        outline: none;
    }

    .btn-custom {
        border: 1px solid var(--text-dark);
        background-color: white;
        font-weight: 600;
        padding: 0.5rem 1.5rem;
        border-radius: 4px;
        transition: 0.2s;
        text-decoration: none;
        color: var(--text-dark);
        display: inline-block;
    }

    .btn-custom:hover {
        background-color: var(--bg-light);
        color: var(--text-dark);
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid var(--text-dark);
        padding: 0.75rem;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table th {
        font-weight: 600;
    }

    .action-btns {
        display: flex;
        gap: 5px;
        justify-content: center;
        flex-wrap: wrap;
    }

    .pagination .page-item:not(:first-child) .page-link {
        margin-left: 5px;
    }

    .page-link {
        color: var(--text-dark);
        border: 1px solid var(--text-dark);
        border-radius: 4px !important;
        font-weight: 600;
    }

    .page-link:hover {
        background-color: var(--light-orange);
        color: var(--primary-orange);
        border-color: var(--primary-orange);
    }

    .page-item.active .page-link {
        background-color: var(--primary-orange);
        color: white;
        border-color: var(--primary-orange);
    }

    .page-item.disabled .page-link {
        color: var(--text-muted);
        border-color: #e5e7eb;
        background-color: #f9fafb;
    }
</style>
<?= $this->endSection('css_content'); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Admin</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<main class="page-content">
    <!-- Cek dan tampilkan pesan 'success' -->
    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('success'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Cek dan tampilkan pesan 'error' -->
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= session()->getFlashdata('error'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <h1 class="page-title">Daftar Transaksi</h1>

    <div class="row g-4 mt-2">
        <div class="action-bar">
            <!-- Form Pencarian -->
            <form action="<?= site_url('daftarTransaksi') ?>" method="get" class="d-flex gap-2">
                <input type="text" name="keyword" value="<?= esc($keyword) ?>" class="search-input" placeholder="Cari transaksi...">
                <button type="submit" class="btn btn-warning">
                    Cari
                </button>
                <?php if (!empty($keyword)): ?>
                    <a href="<?= site_url('daftarTransaksi') ?>" class="btn-custom" style="background-color: #fee2e2;">Reset</a>
                <?php endif; ?>
            </form>
            <a href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambahTransaksi">
                <i class="fa-solid fa-plus"></i> Tambah Transaksi
            </a>
        </div>

        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No. Transaksi</th>
                        <th>Nama</th>
                        <th>Tgl. Order</th>
                        <th>Status</th>
                        <th>Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($transaksi) && count($transaksi) > 0) : ?>
                        <?php
                        $no = 1 + ($perPage * ($currentPage - 1));
                        foreach ($transaksi as $row) :
                            $statusPengerjaan = empty($row['tgl_selesai']) ? 'Proses' : 'Selesai';
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= esc($row['no_transaksi'] ?? '-'); ?></td>
                                <td><?= esc($row['nama_pelanggan'] ?? '-'); ?></td>

                                <!-- Tanggal Terima -->
                                <td>
                                    <?php
                                    if (!empty($row['tgl_terima']) && $row['tgl_terima'] !== '0000-00-00 00:00:00') {
                                        echo date('d-M-Y', strtotime($row['tgl_terima']));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>

                                <td>
                                    <?php if ($row['status'] == 'antri'): ?>
                                        <span class="badge bg-secondary">Antri</span>
                                    <?php elseif ($row['status'] == 'proses'): ?>
                                        <span class="badge bg-warning text-dark">Proses</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Selesai</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['tgl_pembayaran'])) : ?>
                                        <span class="badge bg-success">Lunas<? //= date(/*'d-M H:i'*/'d-M-Y', strtotime($row['tgl_pembayaran'])); 
                                                                            ?></span>
                                    <?php else : ?>
                                        <span class="badge bg-danger">Belum Lunas</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <!-- Tombol Edit -->
                                        <button type="button"
                                            class="btn btn-sm btn-info text-white"
                                            data-bs-toggle="modal"
                                            data-bs-target="#modalEditTransaksi"
                                            data-id="<?= esc($row['no_transaksi']); ?>"
                                            data-tglterima="<?= esc(date('Y-m-d', strtotime($row['tgl_terima']))); ?>"
                                            data-tglselesai="<?= !empty($row['tgl_selesai']) ? esc(date('Y-m-d', strtotime($row['tgl_selesai']))) : ''; ?>"
                                            data-status="<?= esc($row['status'])  ?? ''; ?>"
                                            data-pembayaran="<?= /*esc($row['tgl_pembayaran']);*/ !empty($row['tgl_pembayaran']) ? 'lunas' : 'belum lunas'; ?>"
                                            data-idpelanggan="<?= esc($row['id_pelanggan'] ?? ''); ?>"
                                            data-namapelanggan="<?= esc($row['nama_pelanggan'] ?? ''); ?>"
                                            style="font-size: 0.8rem;">
                                            Edit
                                        </button>

                                        <!-- Tombol Hapus: Hanya muncul jika tgl_selesai masih NULL (Proses) -->
                                        <?php if (empty($row['tgl_selesai'])) : ?>
                                            <a href="<?= site_url('hapusTransaksi/' . $row['no_transaksi']); ?>"
                                                class="btn-custom py-1 px-2 text-decoration-none text-center"
                                                style="font-size: 0.8rem; background-color: #dc3545; color: white;"
                                                onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi <?= $row['no_transaksi']; ?>?')">
                                                Hapus
                                            </a>
                                        <?php endif; ?>

                                        <!-- Tombol Detail -->
                                        <a href="<?= site_url('detailTransaksi/' . $row['no_transaksi']); ?>" class="btn btn-sm btn-warning text-white">
                                            <i class="fa-solid fa-eye"></i> Detail
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="7" class="text-center">Data transaksi tidak ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Render Pagination Custom -->
        <?= $pager->links('transaksi', 'custom_pager'); ?>

    </div>
</main>



<!-- ================= MODAL UTAMA: TAMBAH TRANSAKSI ================= -->
<div class="modal fade" id="modalTambahTransaksi" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold" id="modalTambahLabel">Tambah Transaksi Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('simpanTransaksi'); ?>" method="post" id="formTambahTransaksi">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- 1. Tgl Order / Terima -->
                        <div class="col-md-6">
                            <label class="form-label font-weight-bold">Tgl. Order / Terima</label>
                            <input type="date" name="tgl_terima" class="form-control" value="<?= date('Y-m-d'); ?>" required>
                        </div>

                        <!-- 2. Status Pembayaran -->
                        <div class="col-md-6">
                            <label class="form-label font-weight-bold">Status Pembayaran</label>
                            <select name="pembayaran" class="form-select" required>
                                <option value="belum lunas">Belum Lunas</option>
                                <option value="lunas">Lunas</option>
                            </select>
                        </div>

                        <!-- 3. Live Search Pelanggan -->
                        <div class="col-md-12">
                            <label class="form-label font-weight-bold">Pelanggan</label>
                            <input type="text" id="searchPelanggan" class="form-control" placeholder="Ketik nama pelanggan..." autocomplete="off" required>
                            <input type="hidden" name="id_pelanggan" id="idPelangganHidden">
                            <!-- Dropdown Hasil Pencarian Live -->
                            <div id="resultPelanggan" class="list-group position-absolute w-100 shadow-sm" style="z-index: 1050; display: none;"></div>
                        </div>

                        <!-- 4. Pilihan Paket Layanan -->
                        <div class="col-md-12">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="form-label font-weight-bold mb-0">Paket Layanan Dipilih</label>
                                <button type="button" class="btn btn-sm btn-outline-primary" id="btnOpenPilihLayanan">
                                    <i class="fa-solid fa-plus"></i> Pilih Paket Layanan
                                </button>
                            </div>
                            <!-- Tabel Ringkasan Paket Terpilih -->
                            <table class="table table-bordered align-middle" id="tableSelectedLayanan">
                                <thead>
                                    <tr class="table-light">
                                        <th>Nama Layanan</th>
                                        <th style="width: 120px;">Jumlah (Qty)</th>
                                        <th style="width: 50px;">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr id="emptyLayananRow">
                                        <td colspan="3" class="text-center text-muted">Belum ada paket layanan terpilih.</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Transaksi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ================= MODAL EDIT TRANSAKSI ================= -->
<div class="modal fade" id="modalEditTransaksi" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-weight-bold">Edit Transaksi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('updateTransaksi'); ?>" method="post" id="formEditTransaksi">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- No. Transaksi (Readonly) -->
                        <div class="col-md-4">
                            <label class="form-label font-weight-bold">No. Transaksi</label>
                            <input type="text" id="editNoTransaksi" name="no_transaksi" class="form-control" readonly>
                        </div>

                        <!-- Tgl Terima -->
                        <div class="col-md-4">
                            <label class="form-label font-weight-bold">Tgl. Order / Terima</label>
                            <input type="date" id="editTglTerima" name="tgl_terima" class="form-control" required>
                        </div>

                        <!-- Status Pengerjaan -->
                        <div class="col-md-4">
                            <label class="form-label font-weight-bold">Status Pengerjaan</label>
                            <select id="editStatusPengerjaan" name="status_pengerjaan" class="form-select" required>
                                <option value="antri">Antri</option>
                                <option value="proses">Proses</option>
                                <option value="selesai">Selesai</option>
                            </select>
                        </div>

                        <!-- Status Pembayaran -->
                        <div class="col-md-6">
                            <label class="form-label font-weight-bold">Status Pembayaran</label>
                            <select id="editPembayaran" name="pembayaran" class="form-select" required>
                                <option value="belum lunas">Belum Lunas</option>
                                <option value="lunas">Lunas</option>
                            </select>
                        </div>

                        <!-- Live Search Pelanggan Edit -->
                        <div class="col-md-6 position-relative">
                            <label class="form-label font-weight-bold">Pelanggan</label>
                            <input type="text" id="searchPelangganEdit" class="form-control" placeholder="Ketik nama pelanggan..." autocomplete="off" required>
                            <input type="hidden" name="id_pelanggan" id="idPelangganHiddenEdit">
                            <div id="resultPelangganEdit" class="list-group position-absolute w-100 shadow-sm" style="z-index: 1050; display: none;"></div>
                        </div>

                        <!-- Table Paket Layanan Edit -->
                        <div class="col-md-12">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="form-label font-weight-bold mb-0">Paket Layanan Dipilih</label>
                                <button type="button" class="btn btn-sm btn-outline-primary" id="btnOpenPilihLayananEdit">
                                    <i class="fa-solid fa-plus"></i> Tambah / Ubah Paket
                                </button>
                            </div>
                            <table class="table table-bordered align-middle" id="tableSelectedLayananEdit">
                                <thead>
                                    <tr class="table-light">
                                        <th>Nama Layanan</th>
                                        <th style="width: 120px;">Jumlah (Qty)</th>
                                        <th style="width: 50px;">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr id="emptyLayananRowEdit">
                                        <td colspan="3" class="text-center text-muted">Belum ada paket layanan terpilih.</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ================= MODAL POP-WINDOW: PILIH LAYANAN MULTI-SELECT ================= -->
<div class="modal fade" id="modalPilihLayanan" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Pilih Paket Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="filterLayanan" class="form-control mb-3" placeholder="Cari paket layanan...">
                <div class="list-group" id="listLayananContainer">
                    <!-- Data Layanan dari Database dimuat via JavaScript -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary w-100" id="btnApplyLayanan">Terapkan Pilihan</button>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {

        // 1. INISIALISASI MODAL BOOTSTRAP
        const modalTambahEl = document.getElementById('modalTambahTransaksi');
        const modalEditEl = document.getElementById('modalEditTransaksi');
        const modalLayananEl = document.getElementById('modalPilihLayanan');

        const modalTambah = bootstrap.Modal.getOrCreateInstance(modalTambahEl);
        const modalEdit = bootstrap.Modal.getOrCreateInstance(modalEditEl);
        const modalLayanan = bootstrap.Modal.getOrCreateInstance(modalLayananEl);

        let activeMode = 'tambah';
        let selectedLayananTambahMap = new Map();
        let selectedLayananEditMap = new Map();

        // 2. FITUR SEARCH LIVE FILTER PAKET LAYANAN (MODAL POP-WINDOW)
        const filterLayananInput = document.getElementById('filterLayanan');
        if (filterLayananInput) {
            filterLayananInput.addEventListener('input', function() {
                const filter = this.value.toLowerCase().trim();
                const items = document.querySelectorAll('#listLayananContainer .list-group-item');

                items.forEach(item => {
                    const text = item.textContent.toLowerCase();
                    if (text.includes(filter)) {
                        item.classList.remove('d-none');
                    } else {
                        item.classList.add('d-none');
                    }
                });
            });
        }

        // 3. FITUR LIVE SEARCH PELANGGAN (MODAL TAMBAH & EDIT)
        function initLiveSearchPelanggan(inputId, hiddenId, resultId) {
            const input = document.getElementById(inputId);
            const hidden = document.getElementById(hiddenId);
            const result = document.getElementById(resultId);

            if (!input || !hidden || !result) return;

            input.addEventListener('input', function() {
                const query = this.value.trim();
                if (query.length < 1) {
                    result.style.display = 'none';
                    hidden.value = '';
                    return;
                }

                fetch(`<?= site_url('getPelangganAjax') ?>?q=${encodeURIComponent(query)}`)
                    .then(res => res.json())
                    .then(data => {
                        result.innerHTML = '';
                        if (data.length > 0) {
                            data.forEach(item => {
                                const a = document.createElement('a');
                                a.href = '#';
                                a.className = 'list-group-item list-group-item-action';
                                a.textContent = item.nama_pelanggan;
                                a.onclick = (e) => {
                                    e.preventDefault();
                                    input.value = item.nama_pelanggan;
                                    hidden.value = item.id_pelanggan;
                                    result.style.display = 'none';
                                };
                                result.appendChild(a);
                            });
                            result.style.display = 'block';
                        } else {
                            result.innerHTML = '<div class="list-group-item text-muted">Pelanggan tidak ditemukan</div>';
                            result.style.display = 'block';
                        }
                    });
            });

            document.addEventListener('click', function(e) {
                if (!input.contains(e.target) && !result.contains(e.target)) {
                    result.style.display = 'none';
                }
            });
        }

        // Jalankan live search pelanggan untuk kedua modal
        initLiveSearchPelanggan('searchPelanggan', 'idPelangganHidden', 'resultPelanggan'); // Tambah
        initLiveSearchPelanggan('searchPelangganEdit', 'idPelangganHiddenEdit', 'resultPelangganEdit'); // Edit

        // 4. NAVIGASI PERPINDAHAN MODAL
        document.getElementById('btnOpenPilihLayanan')?.addEventListener('click', function() {
            activeMode = 'tambah';
            modalTambah.hide();
            setTimeout(() => modalLayanan.show(), 200);
        });

        document.getElementById('btnOpenPilihLayananEdit')?.addEventListener('click', function() {
            activeMode = 'edit';
            modalEdit.hide();
            setTimeout(() => modalLayanan.show(), 200);
        });

        modalLayananEl.addEventListener('hidden.bs.modal', function() {
            if (activeMode === 'tambah') modalTambah.show();
            else modalEdit.show();
        });

        // 5. EDIT: TAMPILKAN HEADER & DETAIL PAKET DARI DB KE MODAL EDIT
        modalEditEl.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            if (!button) return;

            const noTransaksi = button.getAttribute('data-id');
            const tglTerima = button.getAttribute('data-tglterima');
            const tglSelesai = button.getAttribute('data-tglselesai');
            const status = button.getAttribute('data-status');
            const pembayaran = button.getAttribute('data-pembayaran');
            const idPelanggan = button.getAttribute('data-idpelanggan');
            const namaPelanggan = button.getAttribute('data-namapelanggan');

            // Populate Header Data
            document.getElementById('editNoTransaksi').value = noTransaksi || '';
            document.getElementById('editTglTerima').value = tglTerima || '';
            document.getElementById('editPembayaran').value = pembayaran || 'belum lunas';
            document.getElementById('editStatusPengerjaan').value = status || 'antri';

            document.getElementById('searchPelangganEdit').value = namaPelanggan || '';
            document.getElementById('idPelangganHiddenEdit').value = idPelanggan || '';

            // Fetch Detail Paket Layanan milik No. Transaksi ini
            selectedLayananEditMap.clear();
            fetch(`<?= site_url('getDetailTransaksiAjax') ?>/${noTransaksi}`)
                .then(res => res.json())
                .then(res => {
                    if (res.status && res.details) {
                        res.details.forEach(item => {
                            // Membaca 'nama paket' (dengan spasi) atau fallback alternatif
                            const namaPaket = item['nama_paket'] || item.nama_paket || item.nama_layanan || 'Paket';
                            selectedLayananEditMap.set(String(item.id_layanan), {
                                nama: namaPaket,
                                jumlah: parseInt(item.jumlah)
                            });
                        });
                        renderSelectedLayananTable('edit');
                    }
                });
        });

        // 6. LOAD DAFTAR LAYANAN PADA MODAL SELEKSI
        modalLayananEl.addEventListener('show.bs.modal', function() {
            document.getElementById('filterLayanan').value = '';
            const activeMap = (activeMode === 'tambah') ? selectedLayananTambahMap : selectedLayananEditMap;

            // Tambahkan parameter no_transaksi jika sedang dalam mode Edit
            let url = `<?= site_url('getLayananAjax') ?>`;
            if (activeMode === 'edit') {
                const noTx = document.getElementById('editNoTransaksi').value;
                if (noTx) {
                    url += `?no_transaksi=${encodeURIComponent(noTx)}`;
                }
            }

            fetch(url)
                .then(res => res.json())
                .then(data => {
                    const container = document.getElementById('listLayananContainer');
                    container.innerHTML = '';
                    data.forEach(item => {
                        const idLayanan = item.id_layanan;
                        const namaLayanan = item['nama_paket'] || item.nama_paket || item.nama_layanan;

                        // Tandai jika layanan ini sebenarnya sudah terhapus (soft delete)
                        const isDeleted = item.deleted_at !== null && item.deleted_at !== undefined;
                        const statusTag = isDeleted ? ' <span class="badge bg-secondary">(Nonaktif)</span>' : '';

                        const isChecked = activeMap.has(String(idLayanan)) ? 'checked' : '';
                        const label = document.createElement('label');
                        label.className = 'list-group-item d-flex justify-content-between align-items-center';
                        label.innerHTML = `
                <div>
                    <input class="form-check-input me-2 chk-layanan" type="checkbox" value="${idLayanan}" data-nama="${namaLayanan}" ${isChecked}>
                    <span>${namaLayanan} <small class="text-muted">(${item.jenis})</small>${statusTag}</span>
                </div>
            `;
                        container.appendChild(label);
                    });
                });
        });

        // 7. TERAPKAN PILIHAN PAKET DARI MODAL SELEKSI
        document.getElementById('btnApplyLayanan').addEventListener('click', function() {
            const activeMap = (activeMode === 'tambah') ? selectedLayananTambahMap : selectedLayananEditMap;
            const checkboxes = document.querySelectorAll('#listLayananContainer .chk-layanan:checked');
            const currentSelectedIds = new Set();

            checkboxes.forEach(chk => {
                const id = chk.value;
                const nama = chk.dataset.nama;
                currentSelectedIds.add(id);

                if (!activeMap.has(id)) {
                    activeMap.set(id, {
                        nama: nama,
                        jumlah: 1
                    });
                }
            });

            for (let [id] of activeMap) {
                if (!currentSelectedIds.has(id)) {
                    activeMap.delete(id);
                }
            }

            renderSelectedLayananTable(activeMode);
            modalLayanan.hide();
        });

        // 8. RENDER TABEL PAKET TERPILIH
        function renderSelectedLayananTable(mode) {
            const isEdit = (mode === 'edit');
            const activeMap = isEdit ? selectedLayananEditMap : selectedLayananTambahMap;
            const tbody = document.querySelector(isEdit ? '#tableSelectedLayananEdit tbody' : '#tableSelectedLayanan tbody');

            if (!tbody) return;
            tbody.innerHTML = '';

            if (activeMap.size === 0) {
                tbody.innerHTML = `<tr><td colspan="3" class="text-center text-muted">Belum ada paket layanan terpilih.</td></tr>`;
                return;
            }

            activeMap.forEach((item, id) => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${item.nama}</td>
                <td>
                    <input type="number" name="items[${id}][jumlah]" class="form-control form-control-sm" value="${item.jumlah}" min="1" required onchange="updateQtyMode('${mode}', '${id}', this.value)">
                    <input type="hidden" name="items[${id}][id_layanan]" value="${id}">
                </td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeLayananMode('${mode}', '${id}')"><i class="fa-solid fa-trash"></i></button>
                </td>
            `;
                tbody.appendChild(tr);
            });
        }

        window.updateQtyMode = function(mode, id, val) {
            const activeMap = (mode === 'edit') ? selectedLayananEditMap : selectedLayananTambahMap;
            if (activeMap.has(id)) {
                activeMap.get(id).jumlah = parseInt(val) || 1;
            }
        };

        window.removeLayananMode = function(mode, id) {
            const activeMap = (mode === 'edit') ? selectedLayananEditMap : selectedLayananTambahMap;
            activeMap.delete(id);
            renderSelectedLayananTable(mode);
        };
    });
</script>


<?= $this->endSection('content'); ?>