<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dashboard Admin</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome untuk Ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-orange: #f97316;
            --light-orange: #fff7ed;
            --dark-orange: #ea580c;
            --text-dark: #1f2937;
            --text-muted: #6b7280;
            --bg-light: #f3f4f6;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-light);
            /* Menambahkan efek gradasi halus di latar belakang */
            background-image: radial-gradient(circle at top right, #fff7ed, #f3f4f6);
            color: var(--text-dark);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        .login-wrapper {
            background-color: white;
            /* Memperhalus border dan menambah border-radius */
            border-radius: 24px;
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 450px;
            /* Efek bayangan (shadow) yang modern dan lembut */
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.06);
            margin: 1.5rem;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .login-header .icon-bg {
            width: 64px;
            height: 64px;
            background-color: var(--light-orange);
            color: var(--primary-orange);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            margin: 0 auto 1rem;
        }

        .login-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-dark);
            margin: 0;
        }

        .login-subtitle {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-top: 0.5rem;
        }

        /* Kotak pembungkus form agar sesuai dengan sketsa namun lebih cantik */
        .form-container {
            border: 1px solid #e5e7eb;
            border-radius: 16px;
            padding: 1.5rem;
            background-color: #fafafa;
            margin-bottom: 1.5rem;
        }

        .form-group-custom {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .form-group-custom label {
            flex: 1;
            font-weight: 600;
            font-size: 0.95rem;
            margin: 0;
            color: var(--text-dark);
        }

        .input-wrapper {
            flex: 2;
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .form-group-custom input {
            width: 100%;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            /* Memberikan ruang untuk ikon di sebelah kiri */
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            outline: none;
            transition: all 0.2s ease;
            font-size: 0.95rem;
            background-color: white;
        }

        .form-group-custom input:focus {
            border-color: var(--primary-orange);
            box-shadow: 0 0 0 4px rgba(249, 115, 22, 0.1);
        }

        /* Garis pemisah yang lebih elegan */
        .separator-line {
            height: 1px;
            background-color: #e5e7eb;
            margin: 1.5rem 0;
            width: 100%;
        }

        .btn-login {
            width: 100%;
            background-color: var(--primary-orange);
            color: white;
            font-weight: 700;
            font-size: 1.05rem;
            padding: 0.85rem;
            border-radius: 12px;
            border: none;
            transition: all 0.2s ease;
            box-shadow: 0 4px 6px -1px rgba(249, 115, 22, 0.2), 0 2px 4px -1px rgba(249, 115, 22, 0.1);
        }

        .btn-login:hover {
            background-color: var(--dark-orange);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px -1px rgba(249, 115, 22, 0.3), 0 4px 6px -1px rgba(249, 115, 22, 0.2);
        }

        /* Penyesuaian responsif untuk layar Tablet */
        @media (max-width: 768px) {
            .login-wrapper {
                padding: 2.5rem 2rem;
            }
        }

        /* Penyesuaian responsif untuk layar HP */
        @media (max-width: 576px) {
            .login-wrapper {
                padding: 2rem 1.25rem;
                margin: 1rem;
            }

            .form-container {
                padding: 1.25rem 1rem;
            }

            .form-group-custom {
                flex-direction: column;
                align-items: flex-start;
                gap: 6px;
            }

            .form-group-custom label {
                margin-bottom: 2px;
                font-size: 0.9rem;
            }

            .input-wrapper {
                width: 100%;
            }

            .login-title {
                font-size: 1.3rem;
            }
        }
    </style>
</head>

<body>

    <div class="login-wrapper">
        <div class="login-header">
            <div class="icon-bg">
                <i class="fa-solid fa-store"></i>
            </div>
            <h2 class="login-title">Halaman Login</h2>
            <p class="login-subtitle">Masukkan username dan password anda!</p>
        </div>
        <?php

        use Kint\Zval\TraceValue;

        if (!empty(session()->getFlashdata('error'))) { ?>
            <div class="alert alert-danger d-flex align-items-center  alert-dismissible fade show" role="alert">
                <div>
                    <?= session()->getFlashdata('error'); ?>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

        <?php } else if ((!empty(session()->get('Success')))) { ?>
            <div class="alert alert-success d-flex align-items-center  alert-dismissible fade show" role="alert">
                <div>
                    <?= session()->get('Success'); ?>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php } ?>

        <form action="<?= site_url('auth/loginProcess') ?>" method="post">
            <!-- Kotak abu-abu yang membungkus input sesuai dengan sketsa -->
            <div class="form-container">
                <div class="form-group-custom">
                    <label for="username">Masukkan<br>username</label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-user"></i>
                        <input type="text" id="username" name="username" placeholder="Username anda..." required>
                    </div>
                </div>

                <div class="separator-line"></div>

                <div class="form-group-custom">
                    <label for="password">Masukkan<br>password</label>
                    <div class="input-wrapper">
                        <i class="fa-solid fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Password anda..." required>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-login">LOGIN SEKARANG</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>