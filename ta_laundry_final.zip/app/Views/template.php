<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= $this->renderSection('tittle'); ?>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-orange: #f97316;
            /* Warna oranye utama */
            --light-orange: #fff7ed;
            --dark-orange: #ea580c;
            --text-dark: #1f2937;
            --text-muted: #6b7280;
            --bg-light: #f3f4f6;
            --sidebar-width: 250px;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        /* --- Sidebar Styles --- */
        #sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            background-color: white;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease-in-out;
            overflow-y: auto;
        }

        @media (max-width: 767.98px) {
            #sidebar {
                transform: translateX(-100%);
            }

            #sidebar.show {
                transform: translateX(0);
            }
        }

        .sidebar-header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
        }

        .sidebar-header h4 {
            color: var(--primary-orange);
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
        }

        .nav-menu {
            padding: 1rem 0;
        }

        .nav-item {
            padding: 0 1rem;
            margin-bottom: 0.5rem;
        }

        .nav-link {
            color: var(--text-muted);
            padding: 0.75rem 1rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            transition: all 0.2s ease;
            font-weight: 500;
        }

        .nav-link i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
            font-size: 1.1rem;
        }

        .nav-link:hover,
        .nav-link.active {
            background-color: var(--light-orange);
            color: var(--primary-orange);
        }

        .nav-link.active {
            box-shadow: inset 3px 0 0 var(--primary-orange);
        }

        .nav-section-title {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #9ca3af;
            margin: 1.5rem 1.5rem 0.5rem;
            font-weight: 700;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 0.5rem;
        }

        .logout-btn {
            color: #dc2626 !important;
            margin-top: auto;
        }

        .logout-btn:hover {
            background-color: #fef2f2 !important;
        }

        /* --- Main Content Styles --- */
        #main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: margin-left 0.3s ease-in-out;
        }

        @media (max-width: 767.98px) {
            #main-content {
                margin-left: 0;
            }
        }

        /* --- Navbar (Top Bar) --- */
        .topbar {
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.02);
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar-toggler {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-dark);
            cursor: pointer;
            padding: 0;
        }

        @media (min-width: 768px) {
            .sidebar-toggler {
                display: none;
            }
        }

        .profile-btn {
            background-color: white;
            border: 1px solid #e5e7eb;
            color: var(--text-dark);
            border-radius: 20px;
            padding: 0.4rem 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .profile-btn:hover {
            background-color: var(--light-orange);
            border-color: var(--primary-orange);
            color: var(--primary-orange);
        }

        .profile-btn i {
            font-size: 1.2rem;
        }

        /* --- Dropdown Profil Styles --- */
        /* Menyembunyikan panah default dropdown bootstrap jika menggunakan class dropdown-toggle */
        .profile-btn::after {
            display: none;
        }

        .dropdown-menu.profile-dropdown {
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            padding: 0.5rem 0;
            margin-top: 10px !important;
        }

        .dropdown-menu.profile-dropdown .dropdown-header {
            color: var(--text-dark);
            font-weight: 700;
            font-size: 0.95rem;
            padding: 0.5rem 1.5rem;
        }

        .dropdown-menu.profile-dropdown .text-muted-small {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 400;
            display: block;
            margin-top: 2px;
        }

        .dropdown-menu.profile-dropdown .dropdown-item {
            padding: 0.5rem 1.5rem;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text-muted);
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
        }

        .dropdown-menu.profile-dropdown .dropdown-item i {
            width: 20px;
            margin-right: 10px;
            font-size: 1rem;
            text-align: center;
        }

        .dropdown-menu.profile-dropdown .dropdown-item:hover {
            background-color: var(--light-orange);
            color: var(--primary-orange);
        }

        .dropdown-menu.profile-dropdown .dropdown-item.text-danger:hover {
            background-color: #fef2f2;
            color: #dc2626 !important;
        }



        /* Overlay untuk backdrop saat sidebar terbuka di mobile */
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1030;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .sidebar-overlay.show {
            display: block;
            opacity: 1;
        }

        @media (min-width: 768px) {
            .sidebar-overlay.show {
                display: none;
            }
        }
    </style>
    <?= $this->renderSection('css_content');  ?>
</head>

<body>

    <!-- Sidebar Overlay for Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside id="sidebar" class="d-flex flex-column">
        <div class="sidebar-header">
            <?= $this->renderSection('sidebar_tittle'); ?>
            <!-- <h4>Dashboard<br>Admin</h4> -->
        </div>
        <ul class="nav flex-column nav-menu flex-grow-1">
            <?php if (session()->get('role') == 'admin') {; ?>
                <li class="nav-item">
                    <a class="nav-link <?= url_is('dashboardAdmin') ? 'active' : '' ?>" href="<?= site_url('dashboardAdmin'); ?>">
                        <i class="fa-solid fa-house"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item mt-2">
                    <a class="nav-link <?= url_is('daftarTransaksi') ? 'active' : '' ?>" href="<?= site_url('daftarTransaksi'); ?>">
                        <i class="fa-solid fa-money-bill-wave"></i> Transaksi
                    </a>
                </li>

                <div class="nav-section-title">Data Master</div>

                <li class="nav-item">
                    <a class="nav-link <?= url_is('daftarPelanggan') ? 'active' : '' ?>" href="<?= site_url('daftarPelanggan'); ?>">
                        <i class="fa-solid fa-users"></i> Pelanggan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= url_is('daftarLayanan') ? 'active' : '' ?>" href="<?= site_url('daftarLayanan'); ?>">
                        <i class="fa-solid fa-box-open"></i> Layanan
                    </a>
                </li>
            <?php } else {; ?>
                <li class="nav-item">
                    <a class="nav-link <?= url_is('dashboardOwner') ? 'active' : '' ?>" href="<?= site_url('dashboardOwner'); ?>">
                        <i class="fa-solid fa-house"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item mt-2">
                    <a class="nav-link <?= url_is('lapPendapatan') ? 'active' : '' ?>" href="<?= site_url('lapPendapatan'); ?>">
                        <i class="fa-solid fa-chart-line"></i> Lap. Pendapatan
                    </a>
                </li>
            <?php }; ?>
            <!-- Spacer to push logout to bottom -->
            <div class="mt-auto"></div>

            <div style="border-top: 1px solid #e5e7eb; margin: 10px 20px;"></div>

            <li class="nav-item mt-2">
                <a class="nav-link logout-btn" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <!-- <a class="nav-link logout-btn" href="<? //= site_url('auth/logout') 
                                                                ?>"> -->
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </a>
            </li>
        </ul>
    </aside>

    <!-- Main Content wrapper -->
    <div id="main-content">

        <!-- Topbar -->
        <header class="topbar">
            <div>
                <!-- Tombol Burger Menu (Hanya tampil di mobile) -->
                <button class="sidebar-toggler" id="sidebarToggleBtn" aria-label="Toggle Navigation">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>

            <!-- Profil Dropdown -->
            <div class="dropdown">
                <button class="profile-btn dropdown-toggle" type="button" id="profileMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="d-none d-sm-inline">PROFIL</span>
                    <i class="fa-solid fa-user-circle"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end profile-dropdown" aria-labelledby="profileMenuButton">
                    <li>
                        <h6 class="dropdown-header">
                            <?= session()->get('role');  ?>
                            <span class="text-muted-small"><?= session()->get('nama_users'); ?></span>
                        </h6>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#inputUbahDataAkun">
                            <i class="fa-solid fa-pencil-alt"></i> Ubah Data Akun
                        </a>
                    </li>

                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                            <i class="fa-solid fa-right-from-bracket"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </header>

        <?= $this->renderSection('content'); ?>
    </div>

    <!-- Change Ubah Data Akun Modal-->
    <div class="modal fade" id="inputUbahDataAkun" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Form Ubah Data Akun</h5>
                    <button class="close btn btn-danger" type="button" data-bs-dismiss="modal" aria-label="Close">
                        <span class="text-light" aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="<?= site_url('/ubahDataAkunProcess') ?>" method="post">
                    <div class="modal-body">
                        <div class="mb-3 fs-4">
                            <label for="UN" class="form-label">Username</label>
                            <input class="form-control" type="text" name="nama_lengkap" id="nama_lengkap" value="<?= session()->get('nama_users') ?>">
                        </div>
                        <div class="mb-3 fs-4">
                            <label for="UN" class="form-label">Username</label>
                            <input class="form-control" type="text" name="username" id="username" value="<?= session()->get('username') ?>">
                        </div>
                        <div class="mb-3 fs-4">
                            <label for="PW" class="form-label">Password</label>
                            <input class="form-control" type="password" name="password" id="password" value="<?= session()->get('password') ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                        <button class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Ubah Data Akun Modal-->

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yakin mau logout?</h5>
                    <button class="close btn btn-danger" type="button" data-bs-dismiss="modal" aria-label="Close">
                        <span class="text-light" aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik tombol "Iya" jika anda yakin mau logout.</div>
                <div class="modal-footer">
                    <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Batal</button>
                    <a class="btn btn-warning" href="<?= site_url('auth/logout') ?>">Iya</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Logout Modal-->


    <!-- Bootstrap JS Bundle with Popper -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // --- Sidebar Logic ---
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
            const sidebarOverlay = document.getElementById('sidebarOverlay');

            // Fungsi untuk membuka sidebar
            function openSidebar() {
                sidebar.classList.add('show');
                sidebarOverlay.classList.add('show');
                // Mengubah icon burger menjadi close
                sidebarToggleBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
            }

            // Fungsi untuk menutup sidebar
            function closeSidebar() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('show');
                // Mengembalikan icon close menjadi burger
                sidebarToggleBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';
            }

            // Event listener untuk tombol toggle
            sidebarToggleBtn.addEventListener('click', function() {
                if (sidebar.classList.contains('show')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            });

            // Tutup sidebar jika overlay (area gelap di luar sidebar) di-klik
            sidebarOverlay.addEventListener('click', closeSidebar);

            // Efek interaktif pada navigasi (simulasi aktif)
            // const navLinks = document.querySelectorAll('.nav-link:not(.logout-btn)');
            // navLinks.forEach(link => {
            //     link.addEventListener('click', function(e) {
            //         e.preventDefault(); // Mencegah reload halaman

            //         // Hapus kelas active dari semua link
            //         navLinks.forEach(l => l.classList.remove('active'));

            //         // Tambahkan kelas active ke link yang diklik
            //         this.classList.add('active');

            //         if (window.innerWidth < 768) {
            //             closeSidebar();
            //         }
            //     });
            // });
        });
    </script>
</body>

</html>