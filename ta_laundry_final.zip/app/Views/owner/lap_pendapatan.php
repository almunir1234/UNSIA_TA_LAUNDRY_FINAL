<?= $this->extend('Views/template.php'); ?>
<?= $this->section('tittle'); ?>
<title>Owner - Laporan Pendapatan</title>
<?= $this->endSection('tittle'); ?>

<?= $this->section('css_content'); ?>
<style>
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark);
        border-radius: 2px;
    }

    .filter-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 1.5rem;
        align-items: center;
    }

    .filter-box {
        border: 1px solid #d1d5db;
        background: white;
        padding: 0.5rem 1rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
        border-radius: 8px;
    }

    .filter-input {
        border: none;
        outline: none;
        font-family: inherit;
        background: transparent;
        cursor: pointer;
        font-size: 0.9rem;
    }

    .btn-filter {
        border: 1px solid var(--text-dark);
        background-color: white;
        color: var(--text-dark);
        padding: 0.5rem 1.5rem;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        transition: 0.2s;
        text-decoration: none;
    }

    .btn-filter:hover {
        background-color: var(--light-orange);
        color: var(--primary-orange);
        border-color: var(--primary-orange);
    }

    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table th,
    .custom-table td {
        border: 1px solid #e5e7eb;
        padding: 1rem;
        text-align: center;
        vertical-align: middle;
    }

    .custom-table th {
        background-color: white;
        font-weight: 600;
        border-top: 2px solid var(--text-dark);
        border-bottom: 2px solid var(--text-dark);
    }

    .custom-table tr:last-child td {
        border-bottom: 2px solid var(--text-dark);
    }

    .pagination .page-item:not(:first-child) .page-link {
        margin-left: 5px;
    }

    .page-link {
        color: var(--text-dark);
        border: 1px solid #e5e7eb;
        border-radius: 8px !important;
        font-weight: 600;
    }

    .page-link:hover {
        background-color: var(--light-orange);
        color: var(--primary-orange);
        border-color: var(--primary-orange);
    }

    .page-item.active .page-link {
        background-color: var(--primary-orange);
        color: white;
        border-color: var(--primary-orange);
    }

    .page-item.disabled .page-link {
        color: var(--text-muted);
        border-color: #e5e7eb;
        background-color: #f9fafb;
    }
</style>
<?= $this->endSection('css_content'); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Owner</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<main class="page-content">
    <h1 class="page-title">Lap. Pendapatan</h1>

    <div class="row g-4 mt-2">
        <!-- Form Filter Section -->
        <form action="<?= site_url('lapPendapatan'); ?>" method="get" class="filter-container">
            <div class="filter-box bg-light fw-bold">Periode :</div>

            <div class="filter-box">
                <label for="start-date" class="m-0 text-muted">Mulai</label>
                <input type="date" id="start-date" name="tgl_mulai" value="<?= esc($tglMulai ?? ''); ?>" class="filter-input" required>
            </div>

            <div class="filter-box">
                <label for="end-date" class="m-0 text-muted">Akhir</label>
                <input type="date" id="end-date" name="tgl_akhir" value="<?= esc($tglAkhir ?? ''); ?>" class="filter-input" required>
            </div>

            <button type="submit" class="btn-filter">Filter</button>
            <?php if (!empty($tglMulai) && !empty($tglAkhir)): ?>
                <a href="<?= site_url('lapPendapatan'); ?>" class="btn-filter" style="background-color: #fee2e2;">Reset</a>
            <?php endif; ?>
        </form>

        <div class="mb-2">
            <span class="fw-semibold">Total Pendapatan: Rp. <?= number_format($totalPendapatan, 0, ',', '.'); ?></span>
        </div>

        <!-- Table Data -->
        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th style="width: 8%">No</th>
                        <th>Periode</th>
                        <th>Pendapatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($tglMulai) || empty($tglAkhir)): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted py-4">
                                Silakan tentukan periode <strong>Mulai</strong> dan <strong>Akhir</strong> lalu klik tombol <strong>Filter</strong>.
                            </td>
                        </tr>
                    <?php elseif (empty($reports)): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted py-4">
                                Tidak ada transaksi lunas pada rentang tanggal tersebut.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php
                        $no = 1 + ($perPage * ($currentPage - 1));
                        foreach ($reports as $row):
                        ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= date('d M Y', strtotime($row['tanggal'])); ?></td>
                                <td>Rp <?= number_format($row['total_harian'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination Links -->
        <?php if (!empty($pager)): ?>
            <div class="d-flex justify-content-end mt-4">
                <?= $pager; ?>
            </div>
        <?php endif; ?>
    </div>
</main>
<?= $this->endSection('content'); ?>