<?=
$this->extend('Views/template.php');
$this->section('tittle'); ?>
<title>Dashboard Owner</title>";
<?= $this->endSection('tittle'); ?>

<?= $this->section('css_content'); ?>
<style>
    /* --- Page Content --- */
    .page-content {
        padding: 2rem;
        flex-grow: 1;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin-bottom: 2rem;
        position: relative;
        display: inline-block;
    }

    /* Garis bawah pada judul "Dashboard" sesuai sketsa */
    .page-title::after {
        content: '';
        position: absolute;
        bottom: -5px;
        left: 0;
        width: 100%;
        height: 4px;
        background-color: var(--text-dark);
        border-radius: 2px;
    }

    /* --- Stat Cards --- */
    .stat-card {
        background-color: white;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        border: 1px solid #f3f4f6;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        border-color: var(--primary-orange);
    }

    .stat-card h5 {
        color: var(--text-muted);
        font-size: 1rem;
        font-weight: 600;
        margin-bottom: 1rem;
    }

    .stat-card .stat-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: var(--text-dark);
        line-height: 1;
    }

    @media (max-width: 768px) {
        .stat-card .stat-value {
            font-size: 1.5rem;
        }
    }
</style>
<?= $this->endSection('css_content'); ?>

<?= $this->section('sidebar_tittle'); ?>
<h4>Dashboard<br>Owner</h4>
<?= $this->endSection('sidebar_tittle'); ?>

<?= $this->section('content'); ?>
<!-- Page Content -->
<main class="page-content">
    <?php if (!empty(session()->get('role'))) { ?>
        <div class="alert alert-success d-flex align-items-center  alert-dismissible fade show" role="alert">
            <div>
                <?= 'selamat datang ' . session()->get('nama_users'); ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>

    <h1 class="page-title">Dashboard</h1>

    <!-- Grid Layout untuk Card Statistik -->
    <div class="row g-4 mt-2">
        <!-- Card 1 -->
        <div class="col-12 col-sm-6 col-lg-6">
            <div class="stat-card">
                <h5>Total Pendapatan Hari ini</h5>
                <div class="stat-value">Rp. <?= number_format($pendapatan_hari_ini, 0, ',', '.'); ?></div>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="col-12 col-sm-6 col-lg-6">
            <div class="stat-card">
                <h5>Total Pendapatan Kemarin</h5>
                <div class="stat-value">Rp. <?= number_format($pendapatan_kemarin, 0, ',', '.'); ?></div>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="col-12 col-sm-6 col-lg-6">
            <div class="stat-card">
                <h5>Total Pendapatan Minggu ini</h5>
                <div class="stat-value">Rp. <?= number_format($pendapatan_minggu_ini, 0, ',', '.'); ?></div>
            </div>
        </div>

        <!-- Card 4 -->
        <div class="col-12 col-sm-6 col-lg-6">
            <div class="stat-card">
                <h5>Total Pendapatan Bulan Ini</h5>
                <div class="stat-value">Rp. <?= number_format($pendapatan_bulan_ini, 0, ',', '.'); ?></div>
            </div>
        </div>
    </div>
</main>
<?= $this->endSection('content'); ?>